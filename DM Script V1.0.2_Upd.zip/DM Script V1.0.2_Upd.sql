USE [master]
GO
/****** Object:  Database [AuditPilot]    Script Date: 4/22/2021 10:47:08 PM ******/
CREATE DATABASE [AuditPilot]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'ADT', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL14.SQLEXPRESS\MSSQL\DATA\ADT.mdf' , SIZE = 8192KB , MAXSIZE = UNLIMITED, FILEGROWTH = 65536KB )
 LOG ON 
( NAME = N'ADT_log', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL14.SQLEXPRESS\MSSQL\DATA\ADT_log.ldf' , SIZE = 8192KB , MAXSIZE = 2048GB , FILEGROWTH = 65536KB )
GO
ALTER DATABASE [AuditPilot] SET COMPATIBILITY_LEVEL = 140
GO
IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [AuditPilot].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO
ALTER DATABASE [AuditPilot] SET ANSI_NULL_DEFAULT OFF 
GO
ALTER DATABASE [AuditPilot] SET ANSI_NULLS OFF 
GO
ALTER DATABASE [AuditPilot] SET ANSI_PADDING OFF 
GO
ALTER DATABASE [AuditPilot] SET ANSI_WARNINGS OFF 
GO
ALTER DATABASE [AuditPilot] SET ARITHABORT OFF 
GO
ALTER DATABASE [AuditPilot] SET AUTO_CLOSE OFF 
GO
ALTER DATABASE [AuditPilot] SET AUTO_SHRINK OFF 
GO
ALTER DATABASE [AuditPilot] SET AUTO_UPDATE_STATISTICS ON 
GO
ALTER DATABASE [AuditPilot] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO
ALTER DATABASE [AuditPilot] SET CURSOR_DEFAULT  GLOBAL 
GO
ALTER DATABASE [AuditPilot] SET CONCAT_NULL_YIELDS_NULL OFF 
GO
ALTER DATABASE [AuditPilot] SET NUMERIC_ROUNDABORT OFF 
GO
ALTER DATABASE [AuditPilot] SET QUOTED_IDENTIFIER OFF 
GO
ALTER DATABASE [AuditPilot] SET RECURSIVE_TRIGGERS OFF 
GO
ALTER DATABASE [AuditPilot] SET  DISABLE_BROKER 
GO
ALTER DATABASE [AuditPilot] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO
ALTER DATABASE [AuditPilot] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO
ALTER DATABASE [AuditPilot] SET TRUSTWORTHY OFF 
GO
ALTER DATABASE [AuditPilot] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO
ALTER DATABASE [AuditPilot] SET PARAMETERIZATION SIMPLE 
GO
ALTER DATABASE [AuditPilot] SET READ_COMMITTED_SNAPSHOT OFF 
GO
ALTER DATABASE [AuditPilot] SET HONOR_BROKER_PRIORITY OFF 
GO
ALTER DATABASE [AuditPilot] SET RECOVERY SIMPLE 
GO
ALTER DATABASE [AuditPilot] SET  MULTI_USER 
GO
ALTER DATABASE [AuditPilot] SET PAGE_VERIFY CHECKSUM  
GO
ALTER DATABASE [AuditPilot] SET DB_CHAINING OFF 
GO
ALTER DATABASE [AuditPilot] SET FILESTREAM( NON_TRANSACTED_ACCESS = OFF ) 
GO
ALTER DATABASE [AuditPilot] SET TARGET_RECOVERY_TIME = 60 SECONDS 
GO
ALTER DATABASE [AuditPilot] SET DELAYED_DURABILITY = DISABLED 
GO
ALTER DATABASE [AuditPilot] SET QUERY_STORE = OFF
GO
USE [AuditPilot]
GO
/****** Object:  UserDefinedFunction [dbo].[FN_REPLACE_FIRST]    Script Date: 4/22/2021 10:47:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION [dbo].[FN_REPLACE_FIRST](@X NVARCHAR(MAX), @F NVARCHAR(MAX), @R NVARCHAR(MAX)) RETURNS NVARCHAR(MAX) AS BEGIN
RETURN STUFF(@X, CHARINDEX(@F, @X), LEN(@F), @R)
END

GO
/****** Object:  UserDefinedFunction [dbo].[Split]    Script Date: 4/22/2021 10:47:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION [dbo].[Split](@String varchar(MAX), @Delimiter char(1))       
returns @temptable TABLE (items varchar(MAX))       
as       
begin      
    declare @idx int       
    declare @slice varchar(8000)       

    select @idx = 1       
        if len(@String)<1 or @String is null  return       

    while @idx!= 0       
    begin       
        set @idx = charindex(@Delimiter,@String)       
        if @idx!=0       
            set @slice = left(@String,@idx - 1)       
        else       
            set @slice = @String       

        if(len(@slice)>0)  
            insert into @temptable(Items) values(@slice)       

        set @String = right(@String,len(@String) - @idx)       
        if len(@String) = 0 break       
    end   
return 
end

GO
/****** Object:  Table [dbo].[AuditResponseCalculations]    Script Date: 4/22/2021 10:47:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[AuditResponseCalculations](
	[AuditResponseCalculationId] [int] IDENTITY(1,1) NOT NULL,
	[AuditResponseId] [int] NULL,
	[AuditId] [int] NULL,
	[SecSectionId] [int] NULL,
	[SecScore] [numeric](5, 2) NULL,
 CONSTRAINT [PK_AuditResponseCalculations] PRIMARY KEY CLUSTERED 
(
	[AuditResponseCalculationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Audits]    Script Date: 4/22/2021 10:47:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Audits](
	[AuditID] [numeric](5, 0) NOT NULL,
	[ScorecardID] [numeric](4, 0) NULL,
	[ADate] [datetime] NULL,
	[Status] [numeric](1, 0) NULL,
	[UserID] [numeric](4, 0) NULL,
 CONSTRAINT [PK_Audits] PRIMARY KEY CLUSTERED 
(
	[AuditID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[UserMaster]    Script Date: 4/22/2021 10:47:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[UserMaster](
	[UserID] [numeric](4, 0) IDENTITY(1,1) NOT NULL,
	[CompanyID] [numeric](5, 0) NOT NULL,
	[RoleID] [numeric](2, 0) NULL,
	[UserName] [varchar](10) NOT NULL,
	[PCode] [varchar](10) NOT NULL,
	[DisplayName] [varchar](25) NOT NULL,
	[Status] [numeric](1, 0) NOT NULL,
	[MgrID] [numeric](4, 0) NULL,
	[Email] [varchar](50) NULL,
	[DOB] [date] NULL,
	[Country] [nvarchar](25) NULL,
	[Gender] [nvarchar](10) NULL,
	[StartDate] [date] NULL,
	[EndDate] [date] NULL,
 CONSTRAINT [PK_UserMaster] PRIMARY KEY CLUSTERED 
(
	[UserID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  View [dbo].[rptCoversionRateVw]    Script Date: 4/22/2021 10:47:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[rptCoversionRateVw]
AS
SELECT arc.AuditId, adt.ScorecardID, SUM(arc.SecScore) AS Score,
                 (SELECT DisplayName
                 FROM    dbo.UserMaster AS UM
                 WHERE (UserID = adt.UserID)) AS UserName
FROM   dbo.AuditResponseCalculations AS arc INNER JOIN
             dbo.Audits AS adt ON arc.AuditId = adt.AuditID
GROUP BY arc.AuditId, adt.UserID, adt.ScorecardID
GO
/****** Object:  Table [dbo].[scQuestions]    Script Date: 4/22/2021 10:47:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[scQuestions](
	[scQuestionID] [numeric](3, 0) NOT NULL,
	[ParamID] [numeric](3, 0) NOT NULL,
	[ParamTitle] [varchar](90) NOT NULL,
	[Seq] [numeric](2, 0) NOT NULL,
	[scSectionID] [numeric](2, 0) NOT NULL,
	[QWght] [numeric](3, 0) NULL,
	[isMandatory] [bit] NULL,
	[IsCommentReq] [bit] NULL,
	[ScorecardID] [numeric](4, 0) NULL,
 CONSTRAINT [PK_scQuestions] PRIMARY KEY CLUSTERED 
(
	[scQuestionID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ScorecardMaster]    Script Date: 4/22/2021 10:47:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ScorecardMaster](
	[ScorecardID] [numeric](4, 0) NOT NULL,
	[ScorecardName] [varchar](20) NOT NULL,
	[Status] [numeric](1, 0) NOT NULL,
	[CompanyID] [numeric](5, 0) NULL,
 CONSTRAINT [PK_ScorecardMastet] PRIMARY KEY CLUSTERED 
(
	[ScorecardID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[scQLov]    Script Date: 4/22/2021 10:47:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[scQLov](
	[scQLOVID] [numeric](5, 0) NOT NULL,
	[scQuestionID] [numeric](3, 0) NOT NULL,
	[scQuestionValues] [varchar](12) NOT NULL,
	[scWeightage] [varchar](max) NULL,
 CONSTRAINT [PK_scQLov] PRIMARY KEY CLUSTERED 
(
	[scQLOVID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[scSections]    Script Date: 4/22/2021 10:47:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[scSections](
	[scSectionID] [numeric](2, 0) NOT NULL,
	[SectionName] [varchar](50) NOT NULL,
	[SectionWght] [numeric](3, 0) NULL,
	[IsNewPage] [bit] NULL,
	[ScorecardID] [numeric](4, 0) NULL,
	[Seq] [numeric](2, 0) NULL,
 CONSTRAINT [PK_scSections] PRIMARY KEY CLUSTERED 
(
	[scSectionID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  View [dbo].[AuditQuestionsVW]    Script Date: 4/22/2021 10:47:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[AuditQuestionsVW]
AS
SELECT TOP (100) PERCENT dbo.ScorecardMaster.ScorecardName, dbo.ScorecardMaster.ScorecardID, dbo.ScorecardMaster.CompanyID, dbo.scSections.Seq AS SSeq, dbo.scSections.SectionName, dbo.scSections.SectionWght, dbo.scSections.IsNewPage, dbo.scQuestions.ParamTitle, 
             dbo.scQuestions.Seq AS QSeq, dbo.scQLov.scQuestionValues
FROM   dbo.scSections INNER JOIN
             dbo.scQuestions ON dbo.scSections.scSectionID = dbo.scQuestions.scSectionID INNER JOIN
             dbo.ScorecardMaster ON dbo.scSections.ScorecardID = dbo.ScorecardMaster.ScorecardID LEFT OUTER JOIN
             dbo.scQLov ON dbo.scQuestions.scQuestionID = dbo.scQLov.scQuestionID
ORDER BY SSeq, QSeq

GO
/****** Object:  Table [dbo].[AuditReponses]    Script Date: 4/22/2021 10:47:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[AuditReponses](
	[AuditResponeID] [bigint] IDENTITY(1,1) NOT NULL,
	[AuditID] [numeric](5, 0) NULL,
	[scQuestionID] [numeric](3, 0) NULL,
	[Response] [varchar](20) NULL,
	[Score] [varchar](10) NULL,
	[QWgt] [nvarchar](10) NULL,
	[comments] [varchar](max) NULL,
 CONSTRAINT [PK_AuditReponses] PRIMARY KEY CLUSTERED 
(
	[AuditResponeID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ParaMaster]    Script Date: 4/22/2021 10:47:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ParaMaster](
	[ParamID] [numeric](3, 0) IDENTITY(1,1) NOT NULL,
	[ParamName] [varchar](90) NOT NULL,
	[ParamType] [varchar](10) NOT NULL,
	[IsDefault] [bit] NULL,
	[Status] [numeric](1, 0) NOT NULL,
 CONSTRAINT [PK_ParaMaster] PRIMARY KEY CLUSTERED 
(
	[ParamID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  View [dbo].[UserAuditsVw]    Script Date: 4/22/2021 10:47:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[UserAuditsVw]
AS
SELECT        dbo.Audits.AuditID, dbo.ScorecardMaster.ScorecardName, dbo.ParaMaster.ParamID, dbo.AuditReponses.Response, dbo.AuditReponses.scQuestionID, dbo.scQuestions.ParamTitle, dbo.ParaMaster.ParamName, 
                         dbo.Audits.UserID, dbo.ScorecardMaster.CompanyID
FROM            dbo.Audits INNER JOIN
                         dbo.AuditReponses ON dbo.Audits.AuditID = dbo.AuditReponses.AuditID INNER JOIN
                         dbo.ScorecardMaster ON dbo.Audits.ScorecardID = dbo.ScorecardMaster.ScorecardID INNER JOIN
                         dbo.scQuestions ON dbo.AuditReponses.scQuestionID = dbo.scQuestions.scQuestionID INNER JOIN
                         dbo.ParaMaster ON dbo.scQuestions.ParamID = dbo.ParaMaster.ParamID
WHERE        (dbo.ParaMaster.ParamID = 1) OR
                         (dbo.ParaMaster.ParamID = 33) OR
                         (dbo.ParaMaster.ParamID = 4)

GO
/****** Object:  Table [dbo].[CompanyMaster]    Script Date: 4/22/2021 10:47:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CompanyMaster](
	[CompanyID] [numeric](5, 0) IDENTITY(1,1) NOT NULL,
	[CompanyName] [varchar](50) NOT NULL,
	[Address] [varchar](250) NULL,
	[ContactNo] [varchar](15) NULL,
	[url] [varchar](90) NULL,
	[Status] [numeric](1, 0) NULL,
 CONSTRAINT [PK_CompanyMaster] PRIMARY KEY CLUSTERED 
(
	[CompanyID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[RoleMaster]    Script Date: 4/22/2021 10:47:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[RoleMaster](
	[RoleID] [numeric](2, 0) NOT NULL,
	[RoleName] [varchar](50) NOT NULL,
 CONSTRAINT [PK_RoleMaster] PRIMARY KEY CLUSTERED 
(
	[RoleID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  View [dbo].[UserInfo]    Script Date: 4/22/2021 10:47:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[UserInfo]
AS
SELECT        dbo.UserMaster.UserID, dbo.UserMaster.UserName, dbo.UserMaster.DisplayName, dbo.CompanyMaster.CompanyName, dbo.RoleMaster.RoleName, dbo.UserMaster.PCode, dbo.UserMaster.CompanyID, 
                         dbo.UserMaster.Email, ISNULL(dbo.UserMaster.MgrID, 0) AS MgrID, dbo.UserMaster.Status
FROM            dbo.CompanyMaster WITH (nolock) INNER JOIN
                         dbo.UserMaster WITH (nolock) ON dbo.CompanyMaster.CompanyID = dbo.UserMaster.CompanyID INNER JOIN
                         dbo.RoleMaster WITH (nolock) ON dbo.UserMaster.RoleID = dbo.RoleMaster.RoleID

GO
/****** Object:  Table [dbo].[Countries]    Script Date: 4/22/2021 10:47:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Countries](
	[Cint] [int] IDENTITY(1,1) NOT NULL,
	[Country] [nvarchar](50) NULL,
	[Code] [nvarchar](5) NULL,
 CONSTRAINT [PK_Countries] PRIMARY KEY CLUSTERED 
(
	[Cint] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Teams]    Script Date: 4/22/2021 10:47:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Teams](
	[TeamID] [numeric](5, 0) IDENTITY(1,1) NOT NULL,
	[TeamName] [varchar](20) NOT NULL,
	[TeamLeadID] [numeric](4, 0) NOT NULL,
 CONSTRAINT [PK_Teams] PRIMARY KEY CLUSTERED 
(
	[TeamID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[UserLog]    Script Date: 4/22/2021 10:47:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[UserLog](
	[LogiD] [numeric](7, 0) NOT NULL,
	[UserId] [numeric](4, 0) NULL,
	[LoggedIn] [datetime] NULL,
	[LoggedOut] [datetime] NULL,
 CONSTRAINT [PK_UserLog] PRIMARY KEY CLUSTERED 
(
	[LogiD] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET IDENTITY_INSERT [dbo].[AuditReponses] ON 
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40571, CAST(1 AS Numeric(5, 0)), CAST(2 AS Numeric(3, 0)), N'Agent 1', N'214', NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40572, CAST(1 AS Numeric(5, 0)), CAST(3 AS Numeric(3, 0)), N'Bosch Admin', NULL, NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40573, CAST(1 AS Numeric(5, 0)), CAST(4 AS Numeric(3, 0)), N'ISH9876', NULL, NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40574, CAST(1 AS Numeric(5, 0)), CAST(5 AS Numeric(3, 0)), N'2021 04 15', NULL, NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40575, CAST(1 AS Numeric(5, 0)), CAST(6 AS Numeric(3, 0)), N'2021 04 12', NULL, NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40576, CAST(1 AS Numeric(5, 0)), CAST(7 AS Numeric(3, 0)), N'7', NULL, NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40577, CAST(1 AS Numeric(5, 0)), CAST(8 AS Numeric(3, 0)), N'Giri', NULL, NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40578, CAST(1 AS Numeric(5, 0)), CAST(9 AS Numeric(3, 0)), N'74', N'74.21', NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40579, CAST(1 AS Numeric(5, 0)), CAST(10 AS Numeric(3, 0)), N'Met', N'100', NULL, N'meet')
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40580, CAST(1 AS Numeric(5, 0)), CAST(11 AS Numeric(3, 0)), N'Met', N'100', NULL, N'ok')
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40581, CAST(1 AS Numeric(5, 0)), CAST(12 AS Numeric(3, 0)), N'4', N'75.00', NULL, N'ok')
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40582, CAST(1 AS Numeric(5, 0)), CAST(13 AS Numeric(3, 0)), N'4', N'60.00', NULL, N'ok')
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40583, CAST(1 AS Numeric(5, 0)), CAST(14 AS Numeric(3, 0)), N'3', N'66.67', NULL, N'ok')
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40584, CAST(2 AS Numeric(5, 0)), CAST(2 AS Numeric(3, 0)), N'Agent 2', N'215', NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40585, CAST(2 AS Numeric(5, 0)), CAST(3 AS Numeric(3, 0)), N'Bosch Admin', NULL, NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40586, CAST(2 AS Numeric(5, 0)), CAST(4 AS Numeric(3, 0)), N'IHO9876', NULL, NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40587, CAST(2 AS Numeric(5, 0)), CAST(5 AS Numeric(3, 0)), N'2021 04 17', NULL, NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40588, CAST(2 AS Numeric(5, 0)), CAST(6 AS Numeric(3, 0)), N'2021 04 06', NULL, NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40589, CAST(2 AS Numeric(5, 0)), CAST(7 AS Numeric(3, 0)), N'6', NULL, NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40590, CAST(2 AS Numeric(5, 0)), CAST(8 AS Numeric(3, 0)), N'Harish', NULL, NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40591, CAST(2 AS Numeric(5, 0)), CAST(9 AS Numeric(3, 0)), N'83', N'83.25', NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40592, CAST(2 AS Numeric(5, 0)), CAST(10 AS Numeric(3, 0)), N'Met', N'100', NULL, N'k')
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40593, CAST(2 AS Numeric(5, 0)), CAST(11 AS Numeric(3, 0)), N'Met', N'100', NULL, N'k')
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40594, CAST(2 AS Numeric(5, 0)), CAST(12 AS Numeric(3, 0)), N'3', N'50.00', NULL, N'k')
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40595, CAST(2 AS Numeric(5, 0)), CAST(13 AS Numeric(3, 0)), N'5', N'80.00', NULL, N'k')
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40596, CAST(2 AS Numeric(5, 0)), CAST(14 AS Numeric(3, 0)), N'4', N'100', NULL, N'k')
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40597, CAST(3 AS Numeric(5, 0)), CAST(2 AS Numeric(3, 0)), N'Ramesh AK', N'4', NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40598, CAST(3 AS Numeric(5, 0)), CAST(3 AS Numeric(3, 0)), N'Suresh BH', NULL, NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40599, CAST(3 AS Numeric(5, 0)), CAST(4 AS Numeric(3, 0)), N'ISD6748', NULL, NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40600, CAST(3 AS Numeric(5, 0)), CAST(5 AS Numeric(3, 0)), N'2021 04 19', NULL, NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40601, CAST(3 AS Numeric(5, 0)), CAST(6 AS Numeric(3, 0)), N'2021 04 15', NULL, NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40602, CAST(3 AS Numeric(5, 0)), CAST(7 AS Numeric(3, 0)), N'7', NULL, NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40603, CAST(3 AS Numeric(5, 0)), CAST(8 AS Numeric(3, 0)), N'Kailash', NULL, NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40604, CAST(3 AS Numeric(5, 0)), CAST(9 AS Numeric(3, 0)), N'31', N'31.30', NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40605, CAST(3 AS Numeric(5, 0)), CAST(10 AS Numeric(3, 0)), N'Not Met', N'0', NULL, N'not fine')
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40606, CAST(3 AS Numeric(5, 0)), CAST(11 AS Numeric(3, 0)), N'Not Met', N'0', NULL, N'not met ')
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40607, CAST(3 AS Numeric(5, 0)), CAST(12 AS Numeric(3, 0)), N'2', N'25.00', NULL, N'ok')
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40608, CAST(3 AS Numeric(5, 0)), CAST(13 AS Numeric(3, 0)), N'4', N'60.00', NULL, N'not sure')
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40609, CAST(3 AS Numeric(5, 0)), CAST(14 AS Numeric(3, 0)), N'2', N'33.33', NULL, N'ok')
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40610, CAST(4 AS Numeric(5, 0)), CAST(2 AS Numeric(3, 0)), N'Agent 1', N'214', NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40611, CAST(4 AS Numeric(5, 0)), CAST(3 AS Numeric(3, 0)), N'Suresh BH', NULL, NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40612, CAST(4 AS Numeric(5, 0)), CAST(4 AS Numeric(3, 0)), N'HJ8934', NULL, NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40613, CAST(4 AS Numeric(5, 0)), CAST(5 AS Numeric(3, 0)), N'2021 04 19', NULL, NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40614, CAST(4 AS Numeric(5, 0)), CAST(6 AS Numeric(3, 0)), N'2021 04 15', NULL, NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40615, CAST(4 AS Numeric(5, 0)), CAST(7 AS Numeric(3, 0)), N'7', NULL, NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40616, CAST(4 AS Numeric(5, 0)), CAST(8 AS Numeric(3, 0)), N'Jagesh', NULL, NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40617, CAST(4 AS Numeric(5, 0)), CAST(9 AS Numeric(3, 0)), N'37', N'37.17', NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40618, CAST(4 AS Numeric(5, 0)), CAST(10 AS Numeric(3, 0)), N'Not Met', N'0', NULL, N'ok')
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40619, CAST(4 AS Numeric(5, 0)), CAST(11 AS Numeric(3, 0)), N'Met', N'100', NULL, N'ok')
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40620, CAST(4 AS Numeric(5, 0)), CAST(12 AS Numeric(3, 0)), N'3', N'50.00', NULL, N'k')
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40621, CAST(4 AS Numeric(5, 0)), CAST(13 AS Numeric(3, 0)), N'2', N'20.00', NULL, N'k')
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40622, CAST(4 AS Numeric(5, 0)), CAST(14 AS Numeric(3, 0)), N'2', N'33.33', NULL, N'k')
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40623, CAST(5 AS Numeric(5, 0)), CAST(2 AS Numeric(3, 0)), N'Agent 2', N'215', NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40624, CAST(5 AS Numeric(5, 0)), CAST(3 AS Numeric(3, 0)), N'Suresh BH', NULL, NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40625, CAST(5 AS Numeric(5, 0)), CAST(4 AS Numeric(3, 0)), N'HJ8838', NULL, NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40626, CAST(5 AS Numeric(5, 0)), CAST(5 AS Numeric(3, 0)), N'2021 04 18', NULL, NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40627, CAST(5 AS Numeric(5, 0)), CAST(6 AS Numeric(3, 0)), N'2021 04 08', NULL, NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40628, CAST(5 AS Numeric(5, 0)), CAST(7 AS Numeric(3, 0)), N'6', NULL, NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40629, CAST(5 AS Numeric(5, 0)), CAST(8 AS Numeric(3, 0)), N'Vignesh', NULL, NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40630, CAST(5 AS Numeric(5, 0)), CAST(9 AS Numeric(3, 0)), N'77', N'77.75', NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40631, CAST(5 AS Numeric(5, 0)), CAST(10 AS Numeric(3, 0)), N'Met', N'100', NULL, N'k')
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40632, CAST(5 AS Numeric(5, 0)), CAST(11 AS Numeric(3, 0)), N'Not Met', N'0', NULL, N'k')
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40633, CAST(5 AS Numeric(5, 0)), CAST(12 AS Numeric(3, 0)), N'5', N'100', NULL, N'k')
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40634, CAST(5 AS Numeric(5, 0)), CAST(13 AS Numeric(3, 0)), N'4', N'60.00', NULL, N'k')
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40635, CAST(5 AS Numeric(5, 0)), CAST(14 AS Numeric(3, 0)), N'4', N'100', NULL, N'k')
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40636, CAST(6 AS Numeric(5, 0)), CAST(2 AS Numeric(3, 0)), N'Test Agent', N'313', NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40637, CAST(6 AS Numeric(5, 0)), CAST(3 AS Numeric(3, 0)), N'Suresh BH', NULL, NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40638, CAST(6 AS Numeric(5, 0)), CAST(4 AS Numeric(3, 0)), N'HJ9945', NULL, NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40639, CAST(6 AS Numeric(5, 0)), CAST(5 AS Numeric(3, 0)), N'2021 04 19', NULL, NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40640, CAST(6 AS Numeric(5, 0)), CAST(6 AS Numeric(3, 0)), N'2021 04 15', NULL, NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40641, CAST(6 AS Numeric(5, 0)), CAST(7 AS Numeric(3, 0)), N'6', NULL, NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40642, CAST(6 AS Numeric(5, 0)), CAST(8 AS Numeric(3, 0)), N'Lilly', NULL, NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40643, CAST(6 AS Numeric(5, 0)), CAST(9 AS Numeric(3, 0)), N'79', N'79.83', NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40644, CAST(6 AS Numeric(5, 0)), CAST(10 AS Numeric(3, 0)), N'Met', N'100', NULL, N'k')
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40645, CAST(6 AS Numeric(5, 0)), CAST(11 AS Numeric(3, 0)), N'Met', N'100', NULL, N'k')
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40646, CAST(6 AS Numeric(5, 0)), CAST(12 AS Numeric(3, 0)), N'5', N'100', NULL, N'k')
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40647, CAST(6 AS Numeric(5, 0)), CAST(13 AS Numeric(3, 0)), N'4', N'60.00', NULL, N'k')
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40648, CAST(6 AS Numeric(5, 0)), CAST(14 AS Numeric(3, 0)), N'3', N'66.67', NULL, N'k')
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40649, CAST(7 AS Numeric(5, 0)), CAST(3 AS Numeric(3, 0)), N'Bosch Admin', NULL, NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40650, CAST(7 AS Numeric(5, 0)), CAST(4 AS Numeric(3, 0)), N'HJ4994', NULL, NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40651, CAST(7 AS Numeric(5, 0)), CAST(5 AS Numeric(3, 0)), N'2021 04 19', NULL, NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40652, CAST(7 AS Numeric(5, 0)), CAST(6 AS Numeric(3, 0)), N'2021 04 14', NULL, NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40653, CAST(7 AS Numeric(5, 0)), CAST(7 AS Numeric(3, 0)), N'5', NULL, NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40654, CAST(7 AS Numeric(5, 0)), CAST(8 AS Numeric(3, 0)), N'Harish', NULL, NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40655, CAST(7 AS Numeric(5, 0)), CAST(9 AS Numeric(3, 0)), N'31', N'31.55', NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40656, CAST(7 AS Numeric(5, 0)), CAST(10 AS Numeric(3, 0)), N'Not Met', N'0', NULL, N'not fine')
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40657, CAST(7 AS Numeric(5, 0)), CAST(11 AS Numeric(3, 0)), N'Met', N'100', NULL, N'k')
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40658, CAST(7 AS Numeric(5, 0)), CAST(12 AS Numeric(3, 0)), N'2', N'25.00', NULL, N'need more')
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40659, CAST(7 AS Numeric(5, 0)), CAST(13 AS Numeric(3, 0)), N'2', N'20.00', NULL, N'no')
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40660, CAST(7 AS Numeric(5, 0)), CAST(14 AS Numeric(3, 0)), N'2', N'33.33', NULL, N'not ok')
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40661, CAST(8 AS Numeric(5, 0)), CAST(3 AS Numeric(3, 0)), N'Bosch Admin', NULL, NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40662, CAST(8 AS Numeric(5, 0)), CAST(4 AS Numeric(3, 0)), N'HJ8838', NULL, NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40663, CAST(8 AS Numeric(5, 0)), CAST(5 AS Numeric(3, 0)), N'2021 04 19', NULL, NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40664, CAST(8 AS Numeric(5, 0)), CAST(6 AS Numeric(3, 0)), N'2021 04 13', NULL, NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40665, CAST(8 AS Numeric(5, 0)), CAST(7 AS Numeric(3, 0)), N'5', NULL, NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40666, CAST(8 AS Numeric(5, 0)), CAST(8 AS Numeric(3, 0)), N'John', NULL, NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40667, CAST(8 AS Numeric(5, 0)), CAST(9 AS Numeric(3, 0)), N'25', N'25.80', NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40668, CAST(8 AS Numeric(5, 0)), CAST(10 AS Numeric(3, 0)), N'Not Met', N'0', NULL, N'not ok')
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40669, CAST(8 AS Numeric(5, 0)), CAST(11 AS Numeric(3, 0)), N'Not Met', N'0', NULL, N'no ok')
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40670, CAST(8 AS Numeric(5, 0)), CAST(12 AS Numeric(3, 0)), N'2', N'25.00', NULL, N'no')
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40671, CAST(8 AS Numeric(5, 0)), CAST(13 AS Numeric(3, 0)), N'3', N'40.00', NULL, N'j')
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40672, CAST(8 AS Numeric(5, 0)), CAST(14 AS Numeric(3, 0)), N'2', N'33.33', NULL, N'p')
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40673, CAST(9 AS Numeric(5, 0)), CAST(2 AS Numeric(3, 0)), N'Agent 1', N'214', NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40674, CAST(9 AS Numeric(5, 0)), CAST(3 AS Numeric(3, 0)), N'Bosch Admin', NULL, NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40675, CAST(9 AS Numeric(5, 0)), CAST(4 AS Numeric(3, 0)), N'HJ99394', NULL, NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40676, CAST(9 AS Numeric(5, 0)), CAST(5 AS Numeric(3, 0)), N'2021 04 19', NULL, NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40677, CAST(9 AS Numeric(5, 0)), CAST(6 AS Numeric(3, 0)), N'2021 04 15', NULL, NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40678, CAST(9 AS Numeric(5, 0)), CAST(7 AS Numeric(3, 0)), N'7', NULL, NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40679, CAST(9 AS Numeric(5, 0)), CAST(8 AS Numeric(3, 0)), N'John', NULL, NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40680, CAST(9 AS Numeric(5, 0)), CAST(9 AS Numeric(3, 0)), N'83', N'83.38', NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40681, CAST(9 AS Numeric(5, 0)), CAST(10 AS Numeric(3, 0)), N'Met', N'100', NULL, N'K')
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40682, CAST(9 AS Numeric(5, 0)), CAST(11 AS Numeric(3, 0)), N'Met', N'100', NULL, N'K')
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40683, CAST(9 AS Numeric(5, 0)), CAST(12 AS Numeric(3, 0)), N'4', N'75.00', NULL, N'k')
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40684, CAST(9 AS Numeric(5, 0)), CAST(13 AS Numeric(3, 0)), N'4', N'60.00', NULL, N'k')
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40685, CAST(9 AS Numeric(5, 0)), CAST(14 AS Numeric(3, 0)), N'4', N'100', NULL, N'k')
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40686, CAST(10 AS Numeric(5, 0)), CAST(2 AS Numeric(3, 0)), N'Test Agent', N'313', NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40687, CAST(10 AS Numeric(5, 0)), CAST(3 AS Numeric(3, 0)), N'Bosch Admin', NULL, NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40688, CAST(10 AS Numeric(5, 0)), CAST(4 AS Numeric(3, 0)), N'HJ9939', NULL, NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40689, CAST(10 AS Numeric(5, 0)), CAST(5 AS Numeric(3, 0)), N'2021 04 18', NULL, NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40690, CAST(10 AS Numeric(5, 0)), CAST(6 AS Numeric(3, 0)), N'2021 04 15', NULL, NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40691, CAST(10 AS Numeric(5, 0)), CAST(7 AS Numeric(3, 0)), N'7', NULL, NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40692, CAST(10 AS Numeric(5, 0)), CAST(8 AS Numeric(3, 0)), N'Kishore', NULL, NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40693, CAST(10 AS Numeric(5, 0)), CAST(9 AS Numeric(3, 0)), N'100', N'100.00', NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40694, CAST(10 AS Numeric(5, 0)), CAST(10 AS Numeric(3, 0)), N'Met', N'100', NULL, N'k')
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40695, CAST(10 AS Numeric(5, 0)), CAST(11 AS Numeric(3, 0)), N'Met', N'100', NULL, N'k')
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40696, CAST(10 AS Numeric(5, 0)), CAST(12 AS Numeric(3, 0)), N'5', N'100', NULL, N'k')
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40697, CAST(10 AS Numeric(5, 0)), CAST(13 AS Numeric(3, 0)), N'6', N'100', NULL, N'k')
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40698, CAST(10 AS Numeric(5, 0)), CAST(14 AS Numeric(3, 0)), N'4', N'100', NULL, N'k')
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40699, CAST(11 AS Numeric(5, 0)), CAST(3 AS Numeric(3, 0)), N'Bosch Admin', NULL, NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40700, CAST(11 AS Numeric(5, 0)), CAST(4 AS Numeric(3, 0)), N'HJ99349', NULL, NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40701, CAST(11 AS Numeric(5, 0)), CAST(5 AS Numeric(3, 0)), N'2021 04 18', NULL, NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40702, CAST(11 AS Numeric(5, 0)), CAST(6 AS Numeric(3, 0)), N'2021 04 16', NULL, NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40703, CAST(11 AS Numeric(5, 0)), CAST(7 AS Numeric(3, 0)), N'8', NULL, NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40704, CAST(11 AS Numeric(5, 0)), CAST(8 AS Numeric(3, 0)), N'Harish', NULL, NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40705, CAST(11 AS Numeric(5, 0)), CAST(9 AS Numeric(3, 0)), N'83', N'83.25', NULL, NULL)
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40706, CAST(11 AS Numeric(5, 0)), CAST(10 AS Numeric(3, 0)), N'Met', N'100', NULL, N'k')
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40707, CAST(11 AS Numeric(5, 0)), CAST(11 AS Numeric(3, 0)), N'Not Met', N'0', NULL, N'k')
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40708, CAST(11 AS Numeric(5, 0)), CAST(12 AS Numeric(3, 0)), N'5', N'100', NULL, N'k')
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40709, CAST(11 AS Numeric(5, 0)), CAST(13 AS Numeric(3, 0)), N'5', N'80.00', NULL, N'k')
GO
INSERT [dbo].[AuditReponses] ([AuditResponeID], [AuditID], [scQuestionID], [Response], [Score], [QWgt], [comments]) VALUES (40710, CAST(11 AS Numeric(5, 0)), CAST(14 AS Numeric(3, 0)), N'4', N'100', NULL, N'k')
GO
SET IDENTITY_INSERT [dbo].[AuditReponses] OFF
GO
SET IDENTITY_INSERT [dbo].[AuditResponseCalculations] ON 
GO
INSERT [dbo].[AuditResponseCalculations] ([AuditResponseCalculationId], [AuditResponseId], [AuditId], [SecSectionId], [SecScore]) VALUES (1085, NULL, 1, 3, CAST(39.38 AS Numeric(5, 2)))
GO
INSERT [dbo].[AuditResponseCalculations] ([AuditResponseCalculationId], [AuditResponseId], [AuditId], [SecSectionId], [SecScore]) VALUES (1086, NULL, 1, 4, CAST(34.83 AS Numeric(5, 2)))
GO
INSERT [dbo].[AuditResponseCalculations] ([AuditResponseCalculationId], [AuditResponseId], [AuditId], [SecSectionId], [SecScore]) VALUES (1087, NULL, 2, 3, CAST(33.75 AS Numeric(5, 2)))
GO
INSERT [dbo].[AuditResponseCalculations] ([AuditResponseCalculationId], [AuditResponseId], [AuditId], [SecSectionId], [SecScore]) VALUES (1088, NULL, 2, 4, CAST(49.50 AS Numeric(5, 2)))
GO
INSERT [dbo].[AuditResponseCalculations] ([AuditResponseCalculationId], [AuditResponseId], [AuditId], [SecSectionId], [SecScore]) VALUES (1089, NULL, 3, 3, CAST(5.63 AS Numeric(5, 2)))
GO
INSERT [dbo].[AuditResponseCalculations] ([AuditResponseCalculationId], [AuditResponseId], [AuditId], [SecSectionId], [SecScore]) VALUES (1090, NULL, 3, 4, CAST(25.67 AS Numeric(5, 2)))
GO
INSERT [dbo].[AuditResponseCalculations] ([AuditResponseCalculationId], [AuditResponseId], [AuditId], [SecSectionId], [SecScore]) VALUES (1091, NULL, 4, 3, CAST(22.50 AS Numeric(5, 2)))
GO
INSERT [dbo].[AuditResponseCalculations] ([AuditResponseCalculationId], [AuditResponseId], [AuditId], [SecSectionId], [SecScore]) VALUES (1092, NULL, 4, 4, CAST(14.67 AS Numeric(5, 2)))
GO
INSERT [dbo].[AuditResponseCalculations] ([AuditResponseCalculationId], [AuditResponseId], [AuditId], [SecSectionId], [SecScore]) VALUES (1093, NULL, 5, 3, CAST(33.75 AS Numeric(5, 2)))
GO
INSERT [dbo].[AuditResponseCalculations] ([AuditResponseCalculationId], [AuditResponseId], [AuditId], [SecSectionId], [SecScore]) VALUES (1094, NULL, 5, 4, CAST(44.00 AS Numeric(5, 2)))
GO
INSERT [dbo].[AuditResponseCalculations] ([AuditResponseCalculationId], [AuditResponseId], [AuditId], [SecSectionId], [SecScore]) VALUES (1095, NULL, 6, 3, CAST(45.00 AS Numeric(5, 2)))
GO
INSERT [dbo].[AuditResponseCalculations] ([AuditResponseCalculationId], [AuditResponseId], [AuditId], [SecSectionId], [SecScore]) VALUES (1096, NULL, 6, 4, CAST(34.83 AS Numeric(5, 2)))
GO
INSERT [dbo].[AuditResponseCalculations] ([AuditResponseCalculationId], [AuditResponseId], [AuditId], [SecSectionId], [SecScore]) VALUES (1097, NULL, 7, 3, CAST(16.88 AS Numeric(5, 2)))
GO
INSERT [dbo].[AuditResponseCalculations] ([AuditResponseCalculationId], [AuditResponseId], [AuditId], [SecSectionId], [SecScore]) VALUES (1098, NULL, 7, 4, CAST(14.67 AS Numeric(5, 2)))
GO
INSERT [dbo].[AuditResponseCalculations] ([AuditResponseCalculationId], [AuditResponseId], [AuditId], [SecSectionId], [SecScore]) VALUES (1099, NULL, 8, 3, CAST(5.63 AS Numeric(5, 2)))
GO
INSERT [dbo].[AuditResponseCalculations] ([AuditResponseCalculationId], [AuditResponseId], [AuditId], [SecSectionId], [SecScore]) VALUES (1100, NULL, 8, 4, CAST(20.17 AS Numeric(5, 2)))
GO
INSERT [dbo].[AuditResponseCalculations] ([AuditResponseCalculationId], [AuditResponseId], [AuditId], [SecSectionId], [SecScore]) VALUES (1101, NULL, 9, 3, CAST(39.38 AS Numeric(5, 2)))
GO
INSERT [dbo].[AuditResponseCalculations] ([AuditResponseCalculationId], [AuditResponseId], [AuditId], [SecSectionId], [SecScore]) VALUES (1102, NULL, 9, 4, CAST(44.00 AS Numeric(5, 2)))
GO
INSERT [dbo].[AuditResponseCalculations] ([AuditResponseCalculationId], [AuditResponseId], [AuditId], [SecSectionId], [SecScore]) VALUES (1103, NULL, 10, 3, CAST(45.00 AS Numeric(5, 2)))
GO
INSERT [dbo].[AuditResponseCalculations] ([AuditResponseCalculationId], [AuditResponseId], [AuditId], [SecSectionId], [SecScore]) VALUES (1104, NULL, 10, 4, CAST(55.00 AS Numeric(5, 2)))
GO
INSERT [dbo].[AuditResponseCalculations] ([AuditResponseCalculationId], [AuditResponseId], [AuditId], [SecSectionId], [SecScore]) VALUES (1105, NULL, 11, 3, CAST(33.75 AS Numeric(5, 2)))
GO
INSERT [dbo].[AuditResponseCalculations] ([AuditResponseCalculationId], [AuditResponseId], [AuditId], [SecSectionId], [SecScore]) VALUES (1106, NULL, 11, 4, CAST(49.50 AS Numeric(5, 2)))
GO
SET IDENTITY_INSERT [dbo].[AuditResponseCalculations] OFF
GO
INSERT [dbo].[Audits] ([AuditID], [ScorecardID], [ADate], [Status], [UserID]) VALUES (CAST(1 AS Numeric(5, 0)), CAST(2 AS Numeric(4, 0)), CAST(N'2021-04-16T19:52:14.180' AS DateTime), CAST(1 AS Numeric(1, 0)), CAST(3 AS Numeric(4, 0)))
GO
INSERT [dbo].[Audits] ([AuditID], [ScorecardID], [ADate], [Status], [UserID]) VALUES (CAST(2 AS Numeric(5, 0)), CAST(2 AS Numeric(4, 0)), CAST(N'2021-04-18T09:35:17.377' AS DateTime), CAST(1 AS Numeric(1, 0)), CAST(3 AS Numeric(4, 0)))
GO
INSERT [dbo].[Audits] ([AuditID], [ScorecardID], [ADate], [Status], [UserID]) VALUES (CAST(3 AS Numeric(5, 0)), CAST(2 AS Numeric(4, 0)), CAST(N'2021-04-19T22:33:43.597' AS DateTime), CAST(1 AS Numeric(1, 0)), CAST(3 AS Numeric(4, 0)))
GO
INSERT [dbo].[Audits] ([AuditID], [ScorecardID], [ADate], [Status], [UserID]) VALUES (CAST(4 AS Numeric(5, 0)), CAST(2 AS Numeric(4, 0)), CAST(N'2021-04-19T22:36:18.650' AS DateTime), CAST(1 AS Numeric(1, 0)), CAST(3 AS Numeric(4, 0)))
GO
INSERT [dbo].[Audits] ([AuditID], [ScorecardID], [ADate], [Status], [UserID]) VALUES (CAST(5 AS Numeric(5, 0)), CAST(2 AS Numeric(4, 0)), CAST(N'2021-04-19T22:39:12.350' AS DateTime), CAST(1 AS Numeric(1, 0)), CAST(3 AS Numeric(4, 0)))
GO
INSERT [dbo].[Audits] ([AuditID], [ScorecardID], [ADate], [Status], [UserID]) VALUES (CAST(6 AS Numeric(5, 0)), CAST(2 AS Numeric(4, 0)), CAST(N'2021-04-19T22:40:36.537' AS DateTime), CAST(1 AS Numeric(1, 0)), CAST(3 AS Numeric(4, 0)))
GO
INSERT [dbo].[Audits] ([AuditID], [ScorecardID], [ADate], [Status], [UserID]) VALUES (CAST(7 AS Numeric(5, 0)), CAST(2 AS Numeric(4, 0)), CAST(N'2021-04-19T22:42:30.780' AS DateTime), CAST(1 AS Numeric(1, 0)), CAST(2 AS Numeric(4, 0)))
GO
INSERT [dbo].[Audits] ([AuditID], [ScorecardID], [ADate], [Status], [UserID]) VALUES (CAST(8 AS Numeric(5, 0)), CAST(2 AS Numeric(4, 0)), CAST(N'2021-04-19T22:44:18.810' AS DateTime), CAST(1 AS Numeric(1, 0)), CAST(2 AS Numeric(4, 0)))
GO
INSERT [dbo].[Audits] ([AuditID], [ScorecardID], [ADate], [Status], [UserID]) VALUES (CAST(9 AS Numeric(5, 0)), CAST(2 AS Numeric(4, 0)), CAST(N'2021-04-19T23:02:12.380' AS DateTime), CAST(1 AS Numeric(1, 0)), CAST(2 AS Numeric(4, 0)))
GO
INSERT [dbo].[Audits] ([AuditID], [ScorecardID], [ADate], [Status], [UserID]) VALUES (CAST(10 AS Numeric(5, 0)), CAST(2 AS Numeric(4, 0)), CAST(N'2021-04-19T23:04:14.257' AS DateTime), CAST(1 AS Numeric(1, 0)), CAST(2 AS Numeric(4, 0)))
GO
INSERT [dbo].[Audits] ([AuditID], [ScorecardID], [ADate], [Status], [UserID]) VALUES (CAST(11 AS Numeric(5, 0)), CAST(2 AS Numeric(4, 0)), CAST(N'2021-04-19T23:05:27.343' AS DateTime), CAST(1 AS Numeric(1, 0)), CAST(2 AS Numeric(4, 0)))
GO
SET IDENTITY_INSERT [dbo].[CompanyMaster] ON 
GO
INSERT [dbo].[CompanyMaster] ([CompanyID], [CompanyName], [Address], [ContactNo], [url], [Status]) VALUES (CAST(1 AS Numeric(5, 0)), N'Relisun', N'Hyderabad', N'Admin', N'wwwkjscard.com', CAST(1 AS Numeric(1, 0)))
GO
INSERT [dbo].[CompanyMaster] ([CompanyID], [CompanyName], [Address], [ContactNo], [url], [Status]) VALUES (CAST(2 AS Numeric(5, 0)), N'Bocsh', N'Hyderabad', N'Admin', N'wwwkjscard2.com', CAST(1 AS Numeric(1, 0)))
GO
INSERT [dbo].[CompanyMaster] ([CompanyID], [CompanyName], [Address], [ContactNo], [url], [Status]) VALUES (CAST(3 AS Numeric(5, 0)), N'Partch', N'Hyderabad', N'Admin', NULL, CAST(1 AS Numeric(1, 0)))
GO
INSERT [dbo].[CompanyMaster] ([CompanyID], [CompanyName], [Address], [ContactNo], [url], [Status]) VALUES (CAST(4 AS Numeric(5, 0)), N'Dos and Donts', N'Hyderabad, 74', N'9040005', N'www.hydrpot.com', CAST(0 AS Numeric(1, 0)))
GO
INSERT [dbo].[CompanyMaster] ([CompanyID], [CompanyName], [Address], [ContactNo], [url], [Status]) VALUES (CAST(5 AS Numeric(5, 0)), N'Sample Company ', N'Hyderabad, 74', N'prototype', N'94000556', CAST(0 AS Numeric(1, 0)))
GO
SET IDENTITY_INSERT [dbo].[CompanyMaster] OFF
GO
SET IDENTITY_INSERT [dbo].[Countries] ON 
GO
INSERT [dbo].[Countries] ([Cint], [Country], [Code]) VALUES (246, N'India', N'IN')
GO
INSERT [dbo].[Countries] ([Cint], [Country], [Code]) VALUES (247, N'United States', N'US')
GO
INSERT [dbo].[Countries] ([Cint], [Country], [Code]) VALUES (248, N'England', N'UK')
GO
INSERT [dbo].[Countries] ([Cint], [Country], [Code]) VALUES (249, N'Canada', N'CA')
GO
SET IDENTITY_INSERT [dbo].[Countries] OFF
GO
SET IDENTITY_INSERT [dbo].[ParaMaster] ON 
GO
INSERT [dbo].[ParaMaster] ([ParamID], [ParamName], [ParamType], [IsDefault], [Status]) VALUES (CAST(1 AS Numeric(3, 0)), N'Agent', N'TextBox', 1, CAST(1 AS Numeric(1, 0)))
GO
INSERT [dbo].[ParaMaster] ([ParamID], [ParamName], [ParamType], [IsDefault], [Status]) VALUES (CAST(2 AS Numeric(3, 0)), N'Auditor', N'TextBox', 1, CAST(1 AS Numeric(1, 0)))
GO
INSERT [dbo].[ParaMaster] ([ParamID], [ParamName], [ParamType], [IsDefault], [Status]) VALUES (CAST(3 AS Numeric(3, 0)), N'Ticket ID', N'TextBox', 1, CAST(1 AS Numeric(1, 0)))
GO
INSERT [dbo].[ParaMaster] ([ParamID], [ParamName], [ParamType], [IsDefault], [Status]) VALUES (CAST(4 AS Numeric(3, 0)), N'Audit Date', N'Date', 1, CAST(1 AS Numeric(1, 0)))
GO
INSERT [dbo].[ParaMaster] ([ParamID], [ParamName], [ParamType], [IsDefault], [Status]) VALUES (CAST(5 AS Numeric(3, 0)), N'Ticket Date', N'Date', 1, CAST(1 AS Numeric(1, 0)))
GO
INSERT [dbo].[ParaMaster] ([ParamID], [ParamName], [ParamType], [IsDefault], [Status]) VALUES (CAST(27 AS Numeric(3, 0)), N'TEXTBOX', N'TextBox', 0, CAST(1 AS Numeric(1, 0)))
GO
INSERT [dbo].[ParaMaster] ([ParamID], [ParamName], [ParamType], [IsDefault], [Status]) VALUES (CAST(28 AS Numeric(3, 0)), N'DATE', N'Date', 0, CAST(1 AS Numeric(1, 0)))
GO
INSERT [dbo].[ParaMaster] ([ParamID], [ParamName], [ParamType], [IsDefault], [Status]) VALUES (CAST(29 AS Numeric(3, 0)), N'LIST', N'List', 0, CAST(1 AS Numeric(1, 0)))
GO
INSERT [dbo].[ParaMaster] ([ParamID], [ParamName], [ParamType], [IsDefault], [Status]) VALUES (CAST(31 AS Numeric(3, 0)), N'LIST-SCALING', N'SList', 0, CAST(1 AS Numeric(1, 0)))
GO
INSERT [dbo].[ParaMaster] ([ParamID], [ParamName], [ParamType], [IsDefault], [Status]) VALUES (CAST(32 AS Numeric(3, 0)), N'Customer Name', N'TextBox', 1, CAST(1 AS Numeric(1, 0)))
GO
INSERT [dbo].[ParaMaster] ([ParamID], [ParamName], [ParamType], [IsDefault], [Status]) VALUES (CAST(33 AS Numeric(3, 0)), N'Rating', N'TextBox', 1, CAST(1 AS Numeric(1, 0)))
GO
INSERT [dbo].[ParaMaster] ([ParamID], [ParamName], [ParamType], [IsDefault], [Status]) VALUES (CAST(34 AS Numeric(3, 0)), N'AuditScore', N'TextBox', 1, CAST(1 AS Numeric(1, 0)))
GO
SET IDENTITY_INSERT [dbo].[ParaMaster] OFF
GO
INSERT [dbo].[RoleMaster] ([RoleID], [RoleName]) VALUES (CAST(1 AS Numeric(2, 0)), N'Admin')
GO
INSERT [dbo].[RoleMaster] ([RoleID], [RoleName]) VALUES (CAST(2 AS Numeric(2, 0)), N'Auditor')
GO
INSERT [dbo].[RoleMaster] ([RoleID], [RoleName]) VALUES (CAST(3 AS Numeric(2, 0)), N'QA')
GO
INSERT [dbo].[RoleMaster] ([RoleID], [RoleName]) VALUES (CAST(4 AS Numeric(2, 0)), N'Auditee')
GO
INSERT [dbo].[RoleMaster] ([RoleID], [RoleName]) VALUES (CAST(5 AS Numeric(2, 0)), N'Support')
GO
INSERT [dbo].[RoleMaster] ([RoleID], [RoleName]) VALUES (CAST(6 AS Numeric(2, 0)), N'CAdmin')
GO
INSERT [dbo].[RoleMaster] ([RoleID], [RoleName]) VALUES (CAST(7 AS Numeric(2, 0)), N'Team Lead')
GO
INSERT [dbo].[RoleMaster] ([RoleID], [RoleName]) VALUES (CAST(8 AS Numeric(2, 0)), N'Agent')
GO
INSERT [dbo].[ScorecardMaster] ([ScorecardID], [ScorecardName], [Status], [CompanyID]) VALUES (CAST(2 AS Numeric(4, 0)), N'Scorecard001 170421', CAST(1 AS Numeric(1, 0)), CAST(2 AS Numeric(5, 0)))
GO
INSERT [dbo].[ScorecardMaster] ([ScorecardID], [ScorecardName], [Status], [CompanyID]) VALUES (CAST(3 AS Numeric(4, 0)), N'Sample 007 Card', CAST(0 AS Numeric(1, 0)), CAST(2 AS Numeric(5, 0)))
GO
INSERT [dbo].[scQLov] ([scQLOVID], [scQuestionID], [scQuestionValues], [scWeightage]) VALUES (CAST(1 AS Numeric(5, 0)), CAST(7 AS Numeric(3, 0)), N'0', N'0')
GO
INSERT [dbo].[scQLov] ([scQLOVID], [scQuestionID], [scQuestionValues], [scWeightage]) VALUES (CAST(2 AS Numeric(5, 0)), CAST(10 AS Numeric(3, 0)), N'Met', N'100')
GO
INSERT [dbo].[scQLov] ([scQLOVID], [scQuestionID], [scQuestionValues], [scWeightage]) VALUES (CAST(3 AS Numeric(5, 0)), CAST(10 AS Numeric(3, 0)), N'Not Met', N'0')
GO
INSERT [dbo].[scQLov] ([scQLOVID], [scQuestionID], [scQuestionValues], [scWeightage]) VALUES (CAST(4 AS Numeric(5, 0)), CAST(11 AS Numeric(3, 0)), N'Met', N'100')
GO
INSERT [dbo].[scQLov] ([scQLOVID], [scQuestionID], [scQuestionValues], [scWeightage]) VALUES (CAST(5 AS Numeric(5, 0)), CAST(11 AS Numeric(3, 0)), N'Not Met', N'0')
GO
INSERT [dbo].[scQLov] ([scQLOVID], [scQuestionID], [scQuestionValues], [scWeightage]) VALUES (CAST(6 AS Numeric(5, 0)), CAST(12 AS Numeric(3, 0)), N'1', N'0')
GO
INSERT [dbo].[scQLov] ([scQLOVID], [scQuestionID], [scQuestionValues], [scWeightage]) VALUES (CAST(7 AS Numeric(5, 0)), CAST(12 AS Numeric(3, 0)), N'2', N'25.00')
GO
INSERT [dbo].[scQLov] ([scQLOVID], [scQuestionID], [scQuestionValues], [scWeightage]) VALUES (CAST(8 AS Numeric(5, 0)), CAST(12 AS Numeric(3, 0)), N'3', N'50.00')
GO
INSERT [dbo].[scQLov] ([scQLOVID], [scQuestionID], [scQuestionValues], [scWeightage]) VALUES (CAST(9 AS Numeric(5, 0)), CAST(12 AS Numeric(3, 0)), N'4', N'75.00')
GO
INSERT [dbo].[scQLov] ([scQLOVID], [scQuestionID], [scQuestionValues], [scWeightage]) VALUES (CAST(10 AS Numeric(5, 0)), CAST(12 AS Numeric(3, 0)), N'5', N'100')
GO
INSERT [dbo].[scQLov] ([scQLOVID], [scQuestionID], [scQuestionValues], [scWeightage]) VALUES (CAST(11 AS Numeric(5, 0)), CAST(13 AS Numeric(3, 0)), N'1', N'0')
GO
INSERT [dbo].[scQLov] ([scQLOVID], [scQuestionID], [scQuestionValues], [scWeightage]) VALUES (CAST(12 AS Numeric(5, 0)), CAST(13 AS Numeric(3, 0)), N'2', N'20.00')
GO
INSERT [dbo].[scQLov] ([scQLOVID], [scQuestionID], [scQuestionValues], [scWeightage]) VALUES (CAST(13 AS Numeric(5, 0)), CAST(13 AS Numeric(3, 0)), N'3', N'40.00')
GO
INSERT [dbo].[scQLov] ([scQLOVID], [scQuestionID], [scQuestionValues], [scWeightage]) VALUES (CAST(14 AS Numeric(5, 0)), CAST(13 AS Numeric(3, 0)), N'4', N'60.00')
GO
INSERT [dbo].[scQLov] ([scQLOVID], [scQuestionID], [scQuestionValues], [scWeightage]) VALUES (CAST(15 AS Numeric(5, 0)), CAST(13 AS Numeric(3, 0)), N'5', N'80.00')
GO
INSERT [dbo].[scQLov] ([scQLOVID], [scQuestionID], [scQuestionValues], [scWeightage]) VALUES (CAST(16 AS Numeric(5, 0)), CAST(13 AS Numeric(3, 0)), N'6', N'100')
GO
INSERT [dbo].[scQLov] ([scQLOVID], [scQuestionID], [scQuestionValues], [scWeightage]) VALUES (CAST(17 AS Numeric(5, 0)), CAST(14 AS Numeric(3, 0)), N'1', N'0')
GO
INSERT [dbo].[scQLov] ([scQLOVID], [scQuestionID], [scQuestionValues], [scWeightage]) VALUES (CAST(18 AS Numeric(5, 0)), CAST(14 AS Numeric(3, 0)), N'2', N'33.33')
GO
INSERT [dbo].[scQLov] ([scQLOVID], [scQuestionID], [scQuestionValues], [scWeightage]) VALUES (CAST(19 AS Numeric(5, 0)), CAST(14 AS Numeric(3, 0)), N'3', N'66.67')
GO
INSERT [dbo].[scQLov] ([scQLOVID], [scQuestionID], [scQuestionValues], [scWeightage]) VALUES (CAST(20 AS Numeric(5, 0)), CAST(14 AS Numeric(3, 0)), N'4', N'100')
GO
INSERT [dbo].[scQLov] ([scQLOVID], [scQuestionID], [scQuestionValues], [scWeightage]) VALUES (CAST(21 AS Numeric(5, 0)), CAST(22 AS Numeric(3, 0)), N'Met', N'100')
GO
INSERT [dbo].[scQLov] ([scQLOVID], [scQuestionID], [scQuestionValues], [scWeightage]) VALUES (CAST(22 AS Numeric(5, 0)), CAST(22 AS Numeric(3, 0)), N'Not Met', N'0')
GO
INSERT [dbo].[scQLov] ([scQLOVID], [scQuestionID], [scQuestionValues], [scWeightage]) VALUES (CAST(23 AS Numeric(5, 0)), CAST(22 AS Numeric(3, 0)), N'NA', N'')
GO
INSERT [dbo].[scQLov] ([scQLOVID], [scQuestionID], [scQuestionValues], [scWeightage]) VALUES (CAST(24 AS Numeric(5, 0)), CAST(22 AS Numeric(3, 0)), N'Met', N'100')
GO
INSERT [dbo].[scQLov] ([scQLOVID], [scQuestionID], [scQuestionValues], [scWeightage]) VALUES (CAST(25 AS Numeric(5, 0)), CAST(22 AS Numeric(3, 0)), N'Not Met', N'0')
GO
INSERT [dbo].[scQLov] ([scQLOVID], [scQuestionID], [scQuestionValues], [scWeightage]) VALUES (CAST(26 AS Numeric(5, 0)), CAST(22 AS Numeric(3, 0)), N'Met', N'100')
GO
INSERT [dbo].[scQLov] ([scQLOVID], [scQuestionID], [scQuestionValues], [scWeightage]) VALUES (CAST(27 AS Numeric(5, 0)), CAST(22 AS Numeric(3, 0)), N'Not Met', N'0')
GO
INSERT [dbo].[scQLov] ([scQLOVID], [scQuestionID], [scQuestionValues], [scWeightage]) VALUES (CAST(28 AS Numeric(5, 0)), CAST(23 AS Numeric(3, 0)), N'Met', N'100')
GO
INSERT [dbo].[scQLov] ([scQLOVID], [scQuestionID], [scQuestionValues], [scWeightage]) VALUES (CAST(29 AS Numeric(5, 0)), CAST(23 AS Numeric(3, 0)), N'Not Met', N'0')
GO
INSERT [dbo].[scQLov] ([scQLOVID], [scQuestionID], [scQuestionValues], [scWeightage]) VALUES (CAST(30 AS Numeric(5, 0)), CAST(24 AS Numeric(3, 0)), N'1', N'0')
GO
INSERT [dbo].[scQLov] ([scQLOVID], [scQuestionID], [scQuestionValues], [scWeightage]) VALUES (CAST(31 AS Numeric(5, 0)), CAST(24 AS Numeric(3, 0)), N'2', N'25.00')
GO
INSERT [dbo].[scQLov] ([scQLOVID], [scQuestionID], [scQuestionValues], [scWeightage]) VALUES (CAST(32 AS Numeric(5, 0)), CAST(24 AS Numeric(3, 0)), N'3', N'50.00')
GO
INSERT [dbo].[scQLov] ([scQLOVID], [scQuestionID], [scQuestionValues], [scWeightage]) VALUES (CAST(33 AS Numeric(5, 0)), CAST(24 AS Numeric(3, 0)), N'4', N'75.00')
GO
INSERT [dbo].[scQLov] ([scQLOVID], [scQuestionID], [scQuestionValues], [scWeightage]) VALUES (CAST(34 AS Numeric(5, 0)), CAST(24 AS Numeric(3, 0)), N'5', N'100')
GO
INSERT [dbo].[scQuestions] ([scQuestionID], [ParamID], [ParamTitle], [Seq], [scSectionID], [QWght], [isMandatory], [IsCommentReq], [ScorecardID]) VALUES (CAST(2 AS Numeric(3, 0)), CAST(1 AS Numeric(3, 0)), N'Agent', CAST(1 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), CAST(0 AS Numeric(3, 0)), 1, 0, CAST(2 AS Numeric(4, 0)))
GO
INSERT [dbo].[scQuestions] ([scQuestionID], [ParamID], [ParamTitle], [Seq], [scSectionID], [QWght], [isMandatory], [IsCommentReq], [ScorecardID]) VALUES (CAST(3 AS Numeric(3, 0)), CAST(2 AS Numeric(3, 0)), N'Auditor', CAST(2 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), CAST(0 AS Numeric(3, 0)), 1, 0, CAST(2 AS Numeric(4, 0)))
GO
INSERT [dbo].[scQuestions] ([scQuestionID], [ParamID], [ParamTitle], [Seq], [scSectionID], [QWght], [isMandatory], [IsCommentReq], [ScorecardID]) VALUES (CAST(4 AS Numeric(3, 0)), CAST(3 AS Numeric(3, 0)), N'Ticket ID', CAST(3 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), CAST(0 AS Numeric(3, 0)), 1, 0, CAST(2 AS Numeric(4, 0)))
GO
INSERT [dbo].[scQuestions] ([scQuestionID], [ParamID], [ParamTitle], [Seq], [scSectionID], [QWght], [isMandatory], [IsCommentReq], [ScorecardID]) VALUES (CAST(5 AS Numeric(3, 0)), CAST(4 AS Numeric(3, 0)), N'Audit Date', CAST(4 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), CAST(0 AS Numeric(3, 0)), 1, 0, CAST(2 AS Numeric(4, 0)))
GO
INSERT [dbo].[scQuestions] ([scQuestionID], [ParamID], [ParamTitle], [Seq], [scSectionID], [QWght], [isMandatory], [IsCommentReq], [ScorecardID]) VALUES (CAST(6 AS Numeric(3, 0)), CAST(5 AS Numeric(3, 0)), N'Ticket Date', CAST(5 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), CAST(0 AS Numeric(3, 0)), 1, 0, CAST(2 AS Numeric(4, 0)))
GO
INSERT [dbo].[scQuestions] ([scQuestionID], [ParamID], [ParamTitle], [Seq], [scSectionID], [QWght], [isMandatory], [IsCommentReq], [ScorecardID]) VALUES (CAST(7 AS Numeric(3, 0)), CAST(33 AS Numeric(3, 0)), N'Rating', CAST(6 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), CAST(0 AS Numeric(3, 0)), 1, 0, CAST(2 AS Numeric(4, 0)))
GO
INSERT [dbo].[scQuestions] ([scQuestionID], [ParamID], [ParamTitle], [Seq], [scSectionID], [QWght], [isMandatory], [IsCommentReq], [ScorecardID]) VALUES (CAST(8 AS Numeric(3, 0)), CAST(32 AS Numeric(3, 0)), N'Customer Name', CAST(7 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), CAST(0 AS Numeric(3, 0)), 1, 0, CAST(2 AS Numeric(4, 0)))
GO
INSERT [dbo].[scQuestions] ([scQuestionID], [ParamID], [ParamTitle], [Seq], [scSectionID], [QWght], [isMandatory], [IsCommentReq], [ScorecardID]) VALUES (CAST(9 AS Numeric(3, 0)), CAST(34 AS Numeric(3, 0)), N'Audit Score', CAST(8 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), CAST(0 AS Numeric(3, 0)), 1, 0, CAST(2 AS Numeric(4, 0)))
GO
INSERT [dbo].[scQuestions] ([scQuestionID], [ParamID], [ParamTitle], [Seq], [scSectionID], [QWght], [isMandatory], [IsCommentReq], [ScorecardID]) VALUES (CAST(10 AS Numeric(3, 0)), CAST(29 AS Numeric(3, 0)), N'SLA', CAST(1 AS Numeric(2, 0)), CAST(3 AS Numeric(2, 0)), CAST(25 AS Numeric(3, 0)), 1, 1, CAST(2 AS Numeric(4, 0)))
GO
INSERT [dbo].[scQuestions] ([scQuestionID], [ParamID], [ParamTitle], [Seq], [scSectionID], [QWght], [isMandatory], [IsCommentReq], [ScorecardID]) VALUES (CAST(11 AS Numeric(3, 0)), CAST(29 AS Numeric(3, 0)), N'Feedback', CAST(2 AS Numeric(2, 0)), CAST(3 AS Numeric(2, 0)), CAST(25 AS Numeric(3, 0)), 1, 1, CAST(2 AS Numeric(4, 0)))
GO
INSERT [dbo].[scQuestions] ([scQuestionID], [ParamID], [ParamTitle], [Seq], [scSectionID], [QWght], [isMandatory], [IsCommentReq], [ScorecardID]) VALUES (CAST(12 AS Numeric(3, 0)), CAST(31 AS Numeric(3, 0)), N'QA', CAST(3 AS Numeric(2, 0)), CAST(3 AS Numeric(2, 0)), CAST(50 AS Numeric(3, 0)), 1, 1, CAST(2 AS Numeric(4, 0)))
GO
INSERT [dbo].[scQuestions] ([scQuestionID], [ParamID], [ParamTitle], [Seq], [scSectionID], [QWght], [isMandatory], [IsCommentReq], [ScorecardID]) VALUES (CAST(13 AS Numeric(3, 0)), CAST(31 AS Numeric(3, 0)), N'Factor', CAST(1 AS Numeric(2, 0)), CAST(4 AS Numeric(2, 0)), CAST(50 AS Numeric(3, 0)), 1, 1, CAST(2 AS Numeric(4, 0)))
GO
INSERT [dbo].[scQuestions] ([scQuestionID], [ParamID], [ParamTitle], [Seq], [scSectionID], [QWght], [isMandatory], [IsCommentReq], [ScorecardID]) VALUES (CAST(14 AS Numeric(3, 0)), CAST(31 AS Numeric(3, 0)), N'Feedback', CAST(2 AS Numeric(2, 0)), CAST(4 AS Numeric(2, 0)), CAST(50 AS Numeric(3, 0)), 1, 1, CAST(2 AS Numeric(4, 0)))
GO
INSERT [dbo].[scQuestions] ([scQuestionID], [ParamID], [ParamTitle], [Seq], [scSectionID], [QWght], [isMandatory], [IsCommentReq], [ScorecardID]) VALUES (CAST(15 AS Numeric(3, 0)), CAST(1 AS Numeric(3, 0)), N'Agent', CAST(1 AS Numeric(2, 0)), CAST(5 AS Numeric(2, 0)), CAST(0 AS Numeric(3, 0)), 1, 0, CAST(3 AS Numeric(4, 0)))
GO
INSERT [dbo].[scQuestions] ([scQuestionID], [ParamID], [ParamTitle], [Seq], [scSectionID], [QWght], [isMandatory], [IsCommentReq], [ScorecardID]) VALUES (CAST(16 AS Numeric(3, 0)), CAST(2 AS Numeric(3, 0)), N'Auditor', CAST(2 AS Numeric(2, 0)), CAST(5 AS Numeric(2, 0)), CAST(0 AS Numeric(3, 0)), 1, 0, CAST(3 AS Numeric(4, 0)))
GO
INSERT [dbo].[scQuestions] ([scQuestionID], [ParamID], [ParamTitle], [Seq], [scSectionID], [QWght], [isMandatory], [IsCommentReq], [ScorecardID]) VALUES (CAST(17 AS Numeric(3, 0)), CAST(3 AS Numeric(3, 0)), N'Ticket ID', CAST(3 AS Numeric(2, 0)), CAST(5 AS Numeric(2, 0)), CAST(0 AS Numeric(3, 0)), 1, 0, CAST(3 AS Numeric(4, 0)))
GO
INSERT [dbo].[scQuestions] ([scQuestionID], [ParamID], [ParamTitle], [Seq], [scSectionID], [QWght], [isMandatory], [IsCommentReq], [ScorecardID]) VALUES (CAST(18 AS Numeric(3, 0)), CAST(4 AS Numeric(3, 0)), N'Audit Date', CAST(4 AS Numeric(2, 0)), CAST(5 AS Numeric(2, 0)), CAST(0 AS Numeric(3, 0)), 1, 0, CAST(3 AS Numeric(4, 0)))
GO
INSERT [dbo].[scQuestions] ([scQuestionID], [ParamID], [ParamTitle], [Seq], [scSectionID], [QWght], [isMandatory], [IsCommentReq], [ScorecardID]) VALUES (CAST(19 AS Numeric(3, 0)), CAST(5 AS Numeric(3, 0)), N'Ticket Date', CAST(5 AS Numeric(2, 0)), CAST(5 AS Numeric(2, 0)), CAST(0 AS Numeric(3, 0)), 1, 0, CAST(3 AS Numeric(4, 0)))
GO
INSERT [dbo].[scQuestions] ([scQuestionID], [ParamID], [ParamTitle], [Seq], [scSectionID], [QWght], [isMandatory], [IsCommentReq], [ScorecardID]) VALUES (CAST(20 AS Numeric(3, 0)), CAST(33 AS Numeric(3, 0)), N'Rating', CAST(6 AS Numeric(2, 0)), CAST(5 AS Numeric(2, 0)), CAST(0 AS Numeric(3, 0)), 1, 0, CAST(3 AS Numeric(4, 0)))
GO
INSERT [dbo].[scQuestions] ([scQuestionID], [ParamID], [ParamTitle], [Seq], [scSectionID], [QWght], [isMandatory], [IsCommentReq], [ScorecardID]) VALUES (CAST(21 AS Numeric(3, 0)), CAST(32 AS Numeric(3, 0)), N'Customer Name', CAST(7 AS Numeric(2, 0)), CAST(5 AS Numeric(2, 0)), CAST(0 AS Numeric(3, 0)), 1, 0, CAST(3 AS Numeric(4, 0)))
GO
INSERT [dbo].[scQuestions] ([scQuestionID], [ParamID], [ParamTitle], [Seq], [scSectionID], [QWght], [isMandatory], [IsCommentReq], [ScorecardID]) VALUES (CAST(22 AS Numeric(3, 0)), CAST(34 AS Numeric(3, 0)), N'Audit Score', CAST(8 AS Numeric(2, 0)), CAST(5 AS Numeric(2, 0)), CAST(0 AS Numeric(3, 0)), 1, 0, CAST(3 AS Numeric(4, 0)))
GO
INSERT [dbo].[scQuestions] ([scQuestionID], [ParamID], [ParamTitle], [Seq], [scSectionID], [QWght], [isMandatory], [IsCommentReq], [ScorecardID]) VALUES (CAST(23 AS Numeric(3, 0)), CAST(29 AS Numeric(3, 0)), N'SLA', CAST(1 AS Numeric(2, 0)), CAST(6 AS Numeric(2, 0)), CAST(100 AS Numeric(3, 0)), 1, 1, CAST(3 AS Numeric(4, 0)))
GO
INSERT [dbo].[scQuestions] ([scQuestionID], [ParamID], [ParamTitle], [Seq], [scSectionID], [QWght], [isMandatory], [IsCommentReq], [ScorecardID]) VALUES (CAST(24 AS Numeric(3, 0)), CAST(31 AS Numeric(3, 0)), N'Factor', CAST(1 AS Numeric(2, 0)), CAST(7 AS Numeric(2, 0)), CAST(100 AS Numeric(3, 0)), 1, 1, CAST(3 AS Numeric(4, 0)))
GO
INSERT [dbo].[scSections] ([scSectionID], [SectionName], [SectionWght], [IsNewPage], [ScorecardID], [Seq]) VALUES (CAST(2 AS Numeric(2, 0)), N'General', CAST(0 AS Numeric(3, 0)), 0, CAST(2 AS Numeric(4, 0)), NULL)
GO
INSERT [dbo].[scSections] ([scSectionID], [SectionName], [SectionWght], [IsNewPage], [ScorecardID], [Seq]) VALUES (CAST(3 AS Numeric(2, 0)), N'Sec001', CAST(45 AS Numeric(3, 0)), 0, CAST(2 AS Numeric(4, 0)), NULL)
GO
INSERT [dbo].[scSections] ([scSectionID], [SectionName], [SectionWght], [IsNewPage], [ScorecardID], [Seq]) VALUES (CAST(4 AS Numeric(2, 0)), N'Sec002', CAST(55 AS Numeric(3, 0)), 0, CAST(2 AS Numeric(4, 0)), NULL)
GO
INSERT [dbo].[scSections] ([scSectionID], [SectionName], [SectionWght], [IsNewPage], [ScorecardID], [Seq]) VALUES (CAST(5 AS Numeric(2, 0)), N'General', CAST(0 AS Numeric(3, 0)), 0, CAST(3 AS Numeric(4, 0)), NULL)
GO
INSERT [dbo].[scSections] ([scSectionID], [SectionName], [SectionWght], [IsNewPage], [ScorecardID], [Seq]) VALUES (CAST(6 AS Numeric(2, 0)), N'Sec002', CAST(60 AS Numeric(3, 0)), 0, CAST(3 AS Numeric(4, 0)), NULL)
GO
INSERT [dbo].[scSections] ([scSectionID], [SectionName], [SectionWght], [IsNewPage], [ScorecardID], [Seq]) VALUES (CAST(7 AS Numeric(2, 0)), N'Sec03', CAST(40 AS Numeric(3, 0)), 0, CAST(3 AS Numeric(4, 0)), NULL)
GO
SET IDENTITY_INSERT [dbo].[Teams] ON 
GO
INSERT [dbo].[Teams] ([TeamID], [TeamName], [TeamLeadID]) VALUES (CAST(1 AS Numeric(5, 0)), N'Morning Shift', CAST(7 AS Numeric(4, 0)))
GO
INSERT [dbo].[Teams] ([TeamID], [TeamName], [TeamLeadID]) VALUES (CAST(2 AS Numeric(5, 0)), N'Night Shift', CAST(8 AS Numeric(4, 0)))
GO
INSERT [dbo].[Teams] ([TeamID], [TeamName], [TeamLeadID]) VALUES (CAST(3 AS Numeric(5, 0)), N'General  S', CAST(109 AS Numeric(4, 0)))
GO
INSERT [dbo].[Teams] ([TeamID], [TeamName], [TeamLeadID]) VALUES (CAST(4 AS Numeric(5, 0)), N'General  Shift', CAST(212 AS Numeric(4, 0)))
GO
SET IDENTITY_INSERT [dbo].[Teams] OFF
GO
SET IDENTITY_INSERT [dbo].[UserMaster] ON 
GO
INSERT [dbo].[UserMaster] ([UserID], [CompanyID], [RoleID], [UserName], [PCode], [DisplayName], [Status], [MgrID], [Email], [DOB], [Country], [Gender], [StartDate], [EndDate]) VALUES (CAST(1 AS Numeric(4, 0)), CAST(1 AS Numeric(5, 0)), CAST(1 AS Numeric(2, 0)), N'Admin', N'admin@123', N'Adminstrator', CAST(0 AS Numeric(1, 0)), NULL, NULL, NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[UserMaster] ([UserID], [CompanyID], [RoleID], [UserName], [PCode], [DisplayName], [Status], [MgrID], [Email], [DOB], [Country], [Gender], [StartDate], [EndDate]) VALUES (CAST(2 AS Numeric(4, 0)), CAST(2 AS Numeric(5, 0)), CAST(6 AS Numeric(2, 0)), N'BAdmin', N'admin@123', N'Bosch Admin', CAST(0 AS Numeric(1, 0)), NULL, NULL, NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[UserMaster] ([UserID], [CompanyID], [RoleID], [UserName], [PCode], [DisplayName], [Status], [MgrID], [Email], [DOB], [Country], [Gender], [StartDate], [EndDate]) VALUES (CAST(3 AS Numeric(4, 0)), CAST(2 AS Numeric(5, 0)), CAST(4 AS Numeric(2, 0)), N'Suresh', N'admin@123', N'Suresh BH', CAST(0 AS Numeric(1, 0)), CAST(7 AS Numeric(4, 0)), NULL, NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[UserMaster] ([UserID], [CompanyID], [RoleID], [UserName], [PCode], [DisplayName], [Status], [MgrID], [Email], [DOB], [Country], [Gender], [StartDate], [EndDate]) VALUES (CAST(4 AS Numeric(4, 0)), CAST(2 AS Numeric(5, 0)), CAST(4 AS Numeric(2, 0)), N'Ramesh', N'admin@123', N'Ramesh AK', CAST(0 AS Numeric(1, 0)), CAST(8 AS Numeric(4, 0)), NULL, NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[UserMaster] ([UserID], [CompanyID], [RoleID], [UserName], [PCode], [DisplayName], [Status], [MgrID], [Email], [DOB], [Country], [Gender], [StartDate], [EndDate]) VALUES (CAST(5 AS Numeric(4, 0)), CAST(3 AS Numeric(5, 0)), CAST(4 AS Numeric(2, 0)), N'Karthik', N'admin@123', N'Karthik D', CAST(0 AS Numeric(1, 0)), NULL, NULL, NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[UserMaster] ([UserID], [CompanyID], [RoleID], [UserName], [PCode], [DisplayName], [Status], [MgrID], [Email], [DOB], [Country], [Gender], [StartDate], [EndDate]) VALUES (CAST(6 AS Numeric(4, 0)), CAST(3 AS Numeric(5, 0)), CAST(6 AS Numeric(2, 0)), N'KAdmin', N'admin@123', N'Parch Admin', CAST(0 AS Numeric(1, 0)), NULL, NULL, NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[UserMaster] ([UserID], [CompanyID], [RoleID], [UserName], [PCode], [DisplayName], [Status], [MgrID], [Email], [DOB], [Country], [Gender], [StartDate], [EndDate]) VALUES (CAST(7 AS Numeric(4, 0)), CAST(2 AS Numeric(5, 0)), CAST(7 AS Numeric(2, 0)), N'Lead1', N'admin@123', N'Morning Lead', CAST(0 AS Numeric(1, 0)), NULL, NULL, NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[UserMaster] ([UserID], [CompanyID], [RoleID], [UserName], [PCode], [DisplayName], [Status], [MgrID], [Email], [DOB], [Country], [Gender], [StartDate], [EndDate]) VALUES (CAST(8 AS Numeric(4, 0)), CAST(2 AS Numeric(5, 0)), CAST(7 AS Numeric(2, 0)), N'Lead2', N'admin@123', N'Leader 0002', CAST(0 AS Numeric(1, 0)), CAST(0 AS Numeric(4, 0)), N'leader2@ghd.com', CAST(N'1987-04-20' AS Date), N'India', N'Male', CAST(N'2021-04-20' AS Date), CAST(N'2022-03-30' AS Date))
GO
INSERT [dbo].[UserMaster] ([UserID], [CompanyID], [RoleID], [UserName], [PCode], [DisplayName], [Status], [MgrID], [Email], [DOB], [Country], [Gender], [StartDate], [EndDate]) VALUES (CAST(16 AS Numeric(4, 0)), CAST(1 AS Numeric(5, 0)), CAST(1 AS Numeric(2, 0)), N'TestUser00', N'terst@123r', N'Test User 0001', CAST(0 AS Numeric(1, 0)), CAST(0 AS Numeric(4, 0)), N'test@g1134.com', NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[UserMaster] ([UserID], [CompanyID], [RoleID], [UserName], [PCode], [DisplayName], [Status], [MgrID], [Email], [DOB], [Country], [Gender], [StartDate], [EndDate]) VALUES (CAST(109 AS Numeric(4, 0)), CAST(2 AS Numeric(5, 0)), CAST(7 AS Numeric(2, 0)), N'TeamLead3', N'admin@123', N'TeamLead 003', CAST(9 AS Numeric(1, 0)), CAST(0 AS Numeric(4, 0)), N'teamlead@tsf.com', CAST(N'1987-04-07' AS Date), N'India', N'Female', CAST(N'2021-04-19' AS Date), CAST(N'2022-03-23' AS Date))
GO
INSERT [dbo].[UserMaster] ([UserID], [CompanyID], [RoleID], [UserName], [PCode], [DisplayName], [Status], [MgrID], [Email], [DOB], [Country], [Gender], [StartDate], [EndDate]) VALUES (CAST(209 AS Numeric(4, 0)), CAST(3 AS Numeric(5, 0)), CAST(1 AS Numeric(2, 0)), N'TestAd', N'zadmin@123', N'test ad ', CAST(0 AS Numeric(1, 0)), CAST(0 AS Numeric(4, 0)), N'testad@testdf.com', NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[UserMaster] ([UserID], [CompanyID], [RoleID], [UserName], [PCode], [DisplayName], [Status], [MgrID], [Email], [DOB], [Country], [Gender], [StartDate], [EndDate]) VALUES (CAST(210 AS Numeric(4, 0)), CAST(4 AS Numeric(5, 0)), CAST(6 AS Numeric(2, 0)), N'testcms', N'admin@123', N'Test Admin Do', CAST(0 AS Numeric(1, 0)), CAST(0 AS Numeric(4, 0)), N'testcms@tsdf.com', NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[UserMaster] ([UserID], [CompanyID], [RoleID], [UserName], [PCode], [DisplayName], [Status], [MgrID], [Email], [DOB], [Country], [Gender], [StartDate], [EndDate]) VALUES (CAST(211 AS Numeric(4, 0)), CAST(4 AS Numeric(5, 0)), CAST(6 AS Numeric(2, 0)), N'ddadmin', N'admin@123', N'DODONTAD', CAST(0 AS Numeric(1, 0)), CAST(0 AS Numeric(4, 0)), N'testdd@tsfd.com', NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[UserMaster] ([UserID], [CompanyID], [RoleID], [UserName], [PCode], [DisplayName], [Status], [MgrID], [Email], [DOB], [Country], [Gender], [StartDate], [EndDate]) VALUES (CAST(212 AS Numeric(4, 0)), CAST(4 AS Numeric(5, 0)), CAST(7 AS Numeric(2, 0)), N'ddtlead', N'admin@123', N'DoDOLead', CAST(0 AS Numeric(1, 0)), CAST(0 AS Numeric(4, 0)), N'ddtlead.fg.com', NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[UserMaster] ([UserID], [CompanyID], [RoleID], [UserName], [PCode], [DisplayName], [Status], [MgrID], [Email], [DOB], [Country], [Gender], [StartDate], [EndDate]) VALUES (CAST(213 AS Numeric(4, 0)), CAST(4 AS Numeric(5, 0)), CAST(4 AS Numeric(2, 0)), N'ddadutiee', N'admin@123', N'DD team MEM', CAST(0 AS Numeric(1, 0)), CAST(212 AS Numeric(4, 0)), N'ddteamm@fg.com', NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[UserMaster] ([UserID], [CompanyID], [RoleID], [UserName], [PCode], [DisplayName], [Status], [MgrID], [Email], [DOB], [Country], [Gender], [StartDate], [EndDate]) VALUES (CAST(214 AS Numeric(4, 0)), CAST(2 AS Numeric(5, 0)), CAST(8 AS Numeric(2, 0)), N'agent1', N'admin@123', N'Agent 1', CAST(0 AS Numeric(1, 0)), CAST(0 AS Numeric(4, 0)), N'agent1@fg.com', NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[UserMaster] ([UserID], [CompanyID], [RoleID], [UserName], [PCode], [DisplayName], [Status], [MgrID], [Email], [DOB], [Country], [Gender], [StartDate], [EndDate]) VALUES (CAST(215 AS Numeric(4, 0)), CAST(2 AS Numeric(5, 0)), CAST(8 AS Numeric(2, 0)), N'agent2', N'admin@123', N'Agent 2', CAST(0 AS Numeric(1, 0)), CAST(0 AS Numeric(4, 0)), N'agent12@fg.com', NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[UserMaster] ([UserID], [CompanyID], [RoleID], [UserName], [PCode], [DisplayName], [Status], [MgrID], [Email], [DOB], [Country], [Gender], [StartDate], [EndDate]) VALUES (CAST(313 AS Numeric(4, 0)), CAST(2 AS Numeric(5, 0)), CAST(8 AS Numeric(2, 0)), N'TestAppUse', N'admin@123', N'Test Agent', CAST(9 AS Numeric(1, 0)), CAST(0 AS Numeric(4, 0)), N'ttest@hgh.com', NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[UserMaster] ([UserID], [CompanyID], [RoleID], [UserName], [PCode], [DisplayName], [Status], [MgrID], [Email], [DOB], [Country], [Gender], [StartDate], [EndDate]) VALUES (CAST(314 AS Numeric(4, 0)), CAST(4 AS Numeric(5, 0)), CAST(5 AS Numeric(2, 0)), N'4aprtestus', N'admin@123', N'Test Apr User', CAST(0 AS Numeric(1, 0)), CAST(0 AS Numeric(4, 0)), N'4aptest@jgj.com', NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[UserMaster] ([UserID], [CompanyID], [RoleID], [UserName], [PCode], [DisplayName], [Status], [MgrID], [Email], [DOB], [Country], [Gender], [StartDate], [EndDate]) VALUES (CAST(317 AS Numeric(4, 0)), CAST(2 AS Numeric(5, 0)), CAST(5 AS Numeric(2, 0)), N'04AprtestB', N'admin@123', N'Test Apr001 User', CAST(9 AS Numeric(1, 0)), CAST(109 AS Numeric(4, 0)), N'4aptest@jghj.com', NULL, NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[UserMaster] ([UserID], [CompanyID], [RoleID], [UserName], [PCode], [DisplayName], [Status], [MgrID], [Email], [DOB], [Country], [Gender], [StartDate], [EndDate]) VALUES (CAST(318 AS Numeric(4, 0)), CAST(2 AS Numeric(5, 0)), CAST(3 AS Numeric(2, 0)), N'TestCompUS', N'admin@123', N'TestCompleteUser', CAST(0 AS Numeric(1, 0)), CAST(0 AS Numeric(4, 0)), N'testcomp@ths.com', CAST(N'1975-06-11' AS Date), N'India', N'Male', CAST(N'2021-04-06' AS Date), CAST(N'2021-08-31' AS Date))
GO
INSERT [dbo].[UserMaster] ([UserID], [CompanyID], [RoleID], [UserName], [PCode], [DisplayName], [Status], [MgrID], [Email], [DOB], [Country], [Gender], [StartDate], [EndDate]) VALUES (CAST(319 AS Numeric(4, 0)), CAST(2 AS Numeric(5, 0)), CAST(3 AS Numeric(2, 0)), N'CtryUserTe', N'admin@123', N'C User Name', CAST(0 AS Numeric(1, 0)), CAST(0 AS Numeric(4, 0)), N'country@gnala.com', CAST(N'1999-10-12' AS Date), N'India', N'Male', CAST(N'2021-04-08' AS Date), CAST(N'2022-03-31' AS Date))
GO
INSERT [dbo].[UserMaster] ([UserID], [CompanyID], [RoleID], [UserName], [PCode], [DisplayName], [Status], [MgrID], [Email], [DOB], [Country], [Gender], [StartDate], [EndDate]) VALUES (CAST(320 AS Numeric(4, 0)), CAST(2 AS Numeric(5, 0)), CAST(3 AS Numeric(2, 0)), N'MyFrgetstU', N'admin@123', N'Foroget', CAST(0 AS Numeric(1, 0)), CAST(0 AS Numeric(4, 0)), N'frgy@jkg.com', CAST(N'1975-06-09' AS Date), N'India', N'Male', CAST(N'2021-04-11' AS Date), CAST(N'2022-06-30' AS Date))
GO
INSERT [dbo].[UserMaster] ([UserID], [CompanyID], [RoleID], [UserName], [PCode], [DisplayName], [Status], [MgrID], [Email], [DOB], [Country], [Gender], [StartDate], [EndDate]) VALUES (CAST(321 AS Numeric(4, 0)), CAST(2 AS Numeric(5, 0)), CAST(3 AS Numeric(2, 0)), N'UserCrErr', N'admin@123', N'User Error Create', CAST(0 AS Numeric(1, 0)), CAST(109 AS Numeric(4, 0)), N'User@ghj.com', CAST(N'1987-04-20' AS Date), N'India', N'Male', CAST(N'2021-04-20' AS Date), CAST(N'2021-09-23' AS Date))
GO
SET IDENTITY_INSERT [dbo].[UserMaster] OFF
GO
ALTER TABLE [dbo].[Audits] ADD  CONSTRAINT [DF_Audits_Status]  DEFAULT ((0)) FOR [Status]
GO
ALTER TABLE [dbo].[CompanyMaster] ADD  CONSTRAINT [DF_CompanyMaster_Status]  DEFAULT ((0)) FOR [Status]
GO
ALTER TABLE [dbo].[ParaMaster] ADD  CONSTRAINT [DF_ParaMaster_Status]  DEFAULT ((0)) FOR [Status]
GO
ALTER TABLE [dbo].[ScorecardMaster] ADD  CONSTRAINT [DF_ScorecardMastet_Status]  DEFAULT ((0)) FOR [Status]
GO
ALTER TABLE [dbo].[scQuestions] ADD  CONSTRAINT [DF_scQuestions_isMandatory]  DEFAULT ((0)) FOR [isMandatory]
GO
ALTER TABLE [dbo].[scQuestions] ADD  CONSTRAINT [DF_scQuestions_IsCommentReq]  DEFAULT ((0)) FOR [IsCommentReq]
GO
ALTER TABLE [dbo].[scSections] ADD  CONSTRAINT [DF_scSections_IsNewPage]  DEFAULT ((0)) FOR [IsNewPage]
GO
ALTER TABLE [dbo].[AuditReponses]  WITH CHECK ADD  CONSTRAINT [FK_AuditReponses_Audits] FOREIGN KEY([AuditID])
REFERENCES [dbo].[Audits] ([AuditID])
GO
ALTER TABLE [dbo].[AuditReponses] CHECK CONSTRAINT [FK_AuditReponses_Audits]
GO
ALTER TABLE [dbo].[AuditReponses]  WITH CHECK ADD  CONSTRAINT [FK_AuditReponses_scQuestions] FOREIGN KEY([scQuestionID])
REFERENCES [dbo].[scQuestions] ([scQuestionID])
GO
ALTER TABLE [dbo].[AuditReponses] CHECK CONSTRAINT [FK_AuditReponses_scQuestions]
GO
ALTER TABLE [dbo].[Audits]  WITH CHECK ADD  CONSTRAINT [FK_Audits_ScorecardMaster] FOREIGN KEY([ScorecardID])
REFERENCES [dbo].[ScorecardMaster] ([ScorecardID])
GO
ALTER TABLE [dbo].[Audits] CHECK CONSTRAINT [FK_Audits_ScorecardMaster]
GO
ALTER TABLE [dbo].[ScorecardMaster]  WITH CHECK ADD  CONSTRAINT [FK_ScorecardMaster_CompanyMaster] FOREIGN KEY([CompanyID])
REFERENCES [dbo].[CompanyMaster] ([CompanyID])
GO
ALTER TABLE [dbo].[ScorecardMaster] CHECK CONSTRAINT [FK_ScorecardMaster_CompanyMaster]
GO
ALTER TABLE [dbo].[scQLov]  WITH CHECK ADD  CONSTRAINT [FK_scQLov_scQuestions] FOREIGN KEY([scQuestionID])
REFERENCES [dbo].[scQuestions] ([scQuestionID])
GO
ALTER TABLE [dbo].[scQLov] CHECK CONSTRAINT [FK_scQLov_scQuestions]
GO
ALTER TABLE [dbo].[scQuestions]  WITH CHECK ADD  CONSTRAINT [FK_scQuestions_ParaMaster] FOREIGN KEY([ParamID])
REFERENCES [dbo].[ParaMaster] ([ParamID])
GO
ALTER TABLE [dbo].[scQuestions] CHECK CONSTRAINT [FK_scQuestions_ParaMaster]
GO
ALTER TABLE [dbo].[scQuestions]  WITH CHECK ADD  CONSTRAINT [FK_scQuestions_scSections] FOREIGN KEY([scSectionID])
REFERENCES [dbo].[scSections] ([scSectionID])
GO
ALTER TABLE [dbo].[scQuestions] CHECK CONSTRAINT [FK_scQuestions_scSections]
GO
ALTER TABLE [dbo].[scSections]  WITH CHECK ADD  CONSTRAINT [FK_scSections_ScorecardMaster] FOREIGN KEY([ScorecardID])
REFERENCES [dbo].[ScorecardMaster] ([ScorecardID])
GO
ALTER TABLE [dbo].[scSections] CHECK CONSTRAINT [FK_scSections_ScorecardMaster]
GO
ALTER TABLE [dbo].[UserLog]  WITH CHECK ADD  CONSTRAINT [FK_UserLog_UserMaster] FOREIGN KEY([UserId])
REFERENCES [dbo].[UserMaster] ([UserID])
GO
ALTER TABLE [dbo].[UserLog] CHECK CONSTRAINT [FK_UserLog_UserMaster]
GO
ALTER TABLE [dbo].[UserMaster]  WITH CHECK ADD  CONSTRAINT [FK_UserMaster_CompanyMaster] FOREIGN KEY([CompanyID])
REFERENCES [dbo].[CompanyMaster] ([CompanyID])
GO
ALTER TABLE [dbo].[UserMaster] CHECK CONSTRAINT [FK_UserMaster_CompanyMaster]
GO
ALTER TABLE [dbo].[UserMaster]  WITH CHECK ADD  CONSTRAINT [FK_UserMaster_RoleMaster] FOREIGN KEY([RoleID])
REFERENCES [dbo].[RoleMaster] ([RoleID])
GO
ALTER TABLE [dbo].[UserMaster] CHECK CONSTRAINT [FK_UserMaster_RoleMaster]
GO
/****** Object:  StoredProcedure [dbo].[AddNewDepartment]    Script Date: 4/22/2021 10:47:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE procedure [dbo].[AddNewDepartment]  
(  
   @DeptName varchar (50), 
   @Address varchar (50),
   @url varchar (10),
   @ContactNo varchar (10)
)  
as  
begin  
   Insert into CompanyMaster values(@DeptName,@Address,@url, @ContactNo,0 )  
End  

GO
/****** Object:  StoredProcedure [dbo].[AddNewTeam]    Script Date: 4/22/2021 10:47:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE procedure [dbo].[AddNewTeam]  
(  
   @TeamName varchar (20),
   @TeamLeadId int
)  
as  
begin  


INSERT INTO [dbo].[Teams]
           ([TeamName]
           ,[TeamLeadID])
     VALUES
           (@TeamName
           ,@TeamLeadId)
  

End  

GO
/****** Object:  StoredProcedure [dbo].[AddNewUser]    Script Date: 4/22/2021 10:47:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE procedure [dbo].[AddNewUser]  
(  
   @UserName varchar (10),
   @DisplayName varchar (25),
   @Passward varchar (10),
   @CompanyId int,
   @RoleId int,
   @Email varchar (56),
   @MgrId int,
   @Dob date,
   @Country nvarchar(20),
   @Gender nvarchar(10),
   @StartDate date,
   @EndDate date

)  
as  
begin  
   
   INSERT INTO [dbo].[UserMaster]
           ([CompanyID]
           ,[RoleID]
           ,[UserName]
           ,[PCode]
           ,[DisplayName]
           ,[Status]
           ,[MgrID]
           ,[Email],
		   [DOB],
		   [Country],
		   [Gender],
		   [StartDate],
		   [EndDate])
     VALUES
           (@CompanyId
           ,@RoleId
           ,@UserName
           ,@Passward
           ,@DisplayName
           ,0
           ,@MgrID
		   ,@Email,
		   @Dob,
		   @Country,
		   @Gender,
		   @StartDate,
		   @EndDate)


End  

GO
/****** Object:  StoredProcedure [dbo].[DeleteDepartmentById]    Script Date: 4/22/2021 10:47:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
Create procedure [dbo].[DeleteDepartmentById]  
(  
   @DeptId int  
)  
as  
begin  
   Delete from CompanyMaster where CompanyId=@DeptId  
End  


/****** Object:  StoredProcedure [dbo].[GetDepartment]    Script Date: 3/26/2021 11:15:13 AM ******/
SET ANSI_NULLS ON

GO
/****** Object:  StoredProcedure [dbo].[DeleteUser]    Script Date: 4/22/2021 10:47:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE procedure [dbo].[DeleteUser]  
(  
   @UserId int
 )  
as  
begin  
   
   Update [dbo].[UserMaster] set
           [Status] = 9
     wHERE UserID = @UserId   


End  

GO
/****** Object:  StoredProcedure [dbo].[GetAuditList]    Script Date: 4/22/2021 10:47:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE Procedure [dbo].[GetAuditList]
(@CompanyID int,
@ScoreCardId int)
AS
BEGIN
select AuditID,ADate,ad.ScorecardID,um.DisplayName as UserID from Audits ad
inner join ScorecardMaster sc on ad.ScorecardID=sc.ScorecardID
inner join UserMaster um on ad.UserID=um.UserID
where sc.CompanyID = @CompanyID and sc.ScorecardID=@ScorecardID
END

GO
/****** Object:  StoredProcedure [dbo].[GetAuditSectionList]    Script Date: 4/22/2021 10:47:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE Procedure [dbo].[GetAuditSectionList]
(@AuditId int)
AS
BEGIN
select AuditId,SecSectionId as SectionId,SecScore,sec.SectionName from 
AuditResponseCalculations ars
right outer join scSections sec on ars.SecSectionId=sec.scSectionID
where AuditId=@AuditId
union
select ad.AuditID,sec.scSectionID as SectionId,0 as SecScore,sec.SectionName from 
scSections sec,Audits ad
where sec.ScorecardID = ad.ScorecardID and ad.AuditID=@AuditId and sec.SectionName='General'

END

GO
/****** Object:  StoredProcedure [dbo].[GetAuditSectionQstList]    Script Date: 4/22/2021 10:47:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE Procedure [dbo].[GetAuditSectionQstList]
(@SectionId int,
@AuditId as int)
AS
BEGIN
select distinct ar.scQuestionID,sq.ParamTitle,sq.ParamID, 
ar.Response,isnull(ar.Score,'') as Score,ar.comments from AuditReponses ar
join scQuestions sq on sq.scQuestionID= ar.scQuestionID and sq.scSectionID=@SectionId
and ar.AuditID=@AuditId
END

GO
/****** Object:  StoredProcedure [dbo].[GetCompaniesList]    Script Date: 4/22/2021 10:47:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE Procedure [dbo].[GetCompaniesList]
AS
BEGIN

select * from [dbo].[CompanyMaster];
END

GO
/****** Object:  StoredProcedure [dbo].[GetCompScoreCardList]    Script Date: 4/22/2021 10:47:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE Procedure [dbo].[GetCompScoreCardList]
(@CompanyId int)
AS
BEGIN
 
select scm.ScorecardID,scm.ScorecardName,
Case 
	When scm.Status = 0 then 'Draft'
	When scm.Status =1 then 'Active'
	Else 'DeActive'
End as Status,
(select count(AuditId) from Audits a where a.ScorecardID=scm.ScorecardID) as Cnt from  
ScorecardMaster as scm where scm.CompanyID = @CompanyId 

 
END 

GO
/****** Object:  StoredProcedure [dbo].[GetDepartment]    Script Date: 4/22/2021 10:47:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE Procedure [dbo].[GetDepartment]    
as    
begin    
   select CompanyID ,CompanyName ,Address,url,contactno  from CompanyMaster  
End   

GO
/****** Object:  StoredProcedure [dbo].[Getdepartments]    Script Date: 4/22/2021 10:47:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE Procedure [dbo].[Getdepartments]    
as    
begin    
--select 0 as RoleId,'Select Role' as RoleName from Roles 
--union
 select CompanyID ,CompanyName ,Address,url,contactno  from CompanyMaster  
End   

GO
/****** Object:  StoredProcedure [dbo].[GetLeads]    Script Date: 4/22/2021 10:47:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE Procedure [dbo].[GetLeads]    
as    
begin    
--select 0 as RoleId,'Select Role' as RoleName from Roles 
--union
   select UserId,DisplayName,CompanyID from UserMaster where RoleID = 7  
End   

GO
/****** Object:  StoredProcedure [dbo].[GetParasmData]    Script Date: 4/22/2021 10:47:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE Procedure [dbo].[GetParasmData]
AS
BEGIN

select ParamID ,ParamName,ParamType from ParaMaster(nolock) where isdefault=0 and ParamID in (29,31)
END

GO
/****** Object:  StoredProcedure [dbo].[GetRoles]    Script Date: 4/22/2021 10:47:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE Procedure [dbo].[GetRoles]    
as    
begin    
--select 0 as RoleId,'Select Role' as RoleName from Roles 
--union
   select RoleId,RoleName from RoleMaster  
End   

GO
/****** Object:  StoredProcedure [dbo].[GetScoreCardList]    Script Date: 4/22/2021 10:47:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE Procedure [dbo].[GetScoreCardList]
(@CompanyID int,
@userId int,
@status int)
AS
BEGIN


select distinct sm.scorecardname,sm.ScorecardID from ScorecardMaster as sm
left join audits as Au on au.ScorecardID=sm.ScorecardID 
where companyid=@CompanyID and sm.Status = @status
--except
--select sm.scorecardname,sm.ScorecardID from ScorecardMaster as sm
--left join audits as Au on au.ScorecardID=sm.ScorecardID 
--where Au.UserID=@userId



END

GO
/****** Object:  StoredProcedure [dbo].[GetScoreCards]    Script Date: 4/22/2021 10:47:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
Create Procedure [dbo].[GetScoreCards]
(@CompanyID int
)
AS
BEGIN


select distinct sm.scorecardname,sm.ScorecardID from ScorecardMaster as sm
inner join audits as Au on au.ScorecardID=sm.ScorecardID 
where companyid=@CompanyID 

END

GO
/****** Object:  StoredProcedure [dbo].[GetSectionData]    Script Date: 4/22/2021 10:47:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE Procedure [dbo].[GetSectionData]
(
@scoreCardName Varchar(21),
@CompanyID int)
AS
Begin

 select SM.ScorecardID,SM.ScorecardName,SS.scSectionID,SS.SectionName,SS.SectionWght,SS.IsNewPage,SS.Seq from ScorecardMaster(nolock) SM
 Inner join scSections(nolock) SS on SM.ScorecardID=SS.ScorecardID
 where SM.ScorecardName=@scoreCardName and CompanyID = @CompanyID

END

GO
/****** Object:  StoredProcedure [dbo].[GetSectionNameWithScorecard]    Script Date: 4/22/2021 10:47:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE Procedure [dbo].[GetSectionNameWithScorecard]    
(    
@sectionName Varchar(21) ,  
@ScorecardName Varchar(21),
@CompanyID int)    
AS    
Begin    
declare @Sectionid int;  
declare @ScorecardID int ; 
select @ScorecardID=ScorecardID from ScorecardMaster(nolock)  where ScorecardName=@ScorecardName and CompanyID= @CompanyID

 select* from [dbo].[scSections] where SectionName = @sectionName and ScorecardID = @ScorecardID  
    
END 

GO
/****** Object:  StoredProcedure [dbo].[GetTeams]    Script Date: 4/22/2021 10:47:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE procedure [dbo].[GetTeams]  

as  
begin  

select TM.TeamLeadID, TM.TeamName,UM.DisplayName,um.CompanyID from Teams TM,UserMaster UM
where  TM.TeamLeadID=um.UserID 
End  

GO
/****** Object:  StoredProcedure [dbo].[GetUserAuditResponseDetails]    Script Date: 4/22/2021 10:47:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE Procedure [dbo].[GetUserAuditResponseDetails]     
(     
@UserID int ,   
@ScorecardID int)     
AS     
Begin     
select ss.SectionName,sq.ParamTitle,ar.Response,ar.Score,ar.comments,ar.AuditResponeID,* from [dbo].[Audits] as au
inner join [dbo].[AuditResponseCalculations] as arc on au.AuditID= arc.AuditID
inner join [dbo].[AuditReponses] as ar on au.AuditID = ar.AuditID
inner join [dbo].[scQuestions] as sq on ar.scQuestionID = sq.scQuestionID
inner join [dbo].[scSections] as ss on sq.scSectionID = ss.scSectionID
where au.UserID = @UserID  and au.ScorecardID = @ScorecardID order by au.AuditID 
     
END 

GO
/****** Object:  StoredProcedure [dbo].[GetUserRespondedScoreCardList]    Script Date: 4/22/2021 10:47:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE Procedure [dbo].[GetUserRespondedScoreCardList]
(@userId int)
AS
BEGIN
 
select distinct scm.ScorecardID,scm.ScorecardName from [dbo].[Audits] as au  
left join ScorecardMaster as scm on au.ScorecardID = scm.ScorecardID
where au.userid = @userId 
 
END 

GO
/****** Object:  StoredProcedure [dbo].[GetUsers]    Script Date: 4/22/2021 10:47:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE Procedure [dbo].[GetUsers]  
(@compid int=null)
as    
begin    
   select U.[UserId]
      ,U.[UserName]
      ,U.PCode as Password,
	  U.CompanyId,
	  U.RoleId,
      D.CompanyName
      ,R.RoleName
      ,U.[Email] from UserMaster U
	  Inner join CompanyMaster D on D.CompanyId=U.CompanyId
	  Inner join RoleMaster R on R.RoleId=U.RoleId 
	  where U.Status != 9
End   

GO
/****** Object:  StoredProcedure [dbo].[InsertIntoParams]    Script Date: 4/22/2021 10:47:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE Procedure [dbo].[InsertIntoParams]
(
@ScoreCardId int ,
@SectionId Int ,
@paramId int,
@paramName Varchar(300),
@ParamWeight int,
@isCurrentReq bit,
@isMandatory bit,
@paramlist Varchar(500) =Null
)
AS
BEGIN
DECLARE @Questionid AS TABLE(QuestionId INT);
DECLARE @xmlStr XML
DECLARE @QSECWght as int;
DECLARE @SecNM as nvarchar(25);


SELECT @SecNM=SectionName FROM scSections WHERE scSectionID=@SectionId
SELECT @QSECWght=ISNULL(SUM(QWght),0) FROM scQuestions WHERE scSectionID=@SectionId AND ScorecardID=@ScoreCardId
IF @QSECWght=null
SELECT @QSECWght=0

IF @ParamWeight + @QSECWght <= 100 or @SecNM = 'General'
BEGIN
BEGIN TRANSACTION
print 'In Condition match'
		--SELECT @xmlStr = Cast( replace(@PrenoteIds,'','''''') as )
		--Select @xmlStr
		SELECT @xmlStr = Cast('<A>'+ replace(@paramlist,',','</A><A>')+ '</A>' As XML)
		SELECT t.value('.', 'Varchar(12)') as Id into #temp
		FROM @xmlStr.nodes('/A') As x(t)
		Declare @topQuestionId int;
		select @topQuestionId=1
		select top 1 @topQuestionId=scQuestionID from scQuestions(nolock) Order by scQuestionID desc
		declare @Qseq int ;
		select @Qseq=0;
print 'sequenc value' 
print @Qseq
		select top 1 @Qseq =ISNULL(seq,0)from scQuestions(nolock) where scSectionID =@SectionId order by seq desc
print 'before question insert' 
print @Qseq
		Insert into [dbo].[scQuestions](scQuestionID,ParamID,ParamTitle,Seq,scSectionID,QWght,isMandatory,IsCommentReq,ScorecardID) --Output Inserted.scQuestionID into @Questionid
		Values(@topQuestionId+1,@paramId, @paramName,Isnull(@Qseq,0)+1,@SectionId,@ParamWeight,@isMandatory,@isCurrentReq,@ScoreCardId)
print 'inserted to questions'	
	Declare @topQuestionId1 int;
		select top 1 @topQuestionId1=scQuestionID from scQuestions(nolock) Order by scQuestionID desc
		--declare @QLovId int ;
		--select top 1 @QLovId=scQLOVID from scQLov(nolock) order by scQLOVID desc
		Declare @Id Varchar(12)
		While (Select Count(*) From #temp) > 0
		BEGIN
		Select Top 1 @Id = Id From #Temp
 
		-- Values(@QLovId+1,(select QuestionId from @Questionid),'')
 
        print 'lov values inside'
		Insert into [dbo].[scQLov](scQLOVID,scQuestionID,scQuestionValues,scWeightage)
		select (select top 1 scQLOVID+1 from scQLov(nolock) order by scQLOVID desc) ,@topQuestionId1,(Select value from(
		SELECT Row_number() over (order by(select 0)) as Rn,* FROM STRING_SPLIT(@Id, '|' )
		) b where rn=1),(Select value from(
		SELECT Row_number() over (order by(select 0)) as Rn,* FROM STRING_SPLIT(@Id , '|' )
		) b where rn=2)
		Delete #Temp Where Id = @Id
		END
 COMMIT TRANSACTION
END
ELSE
BEGIN
print 'failed condition matched'
	select top 1 @topQuestionId=scQuestionID from scQuestions(nolock) Order by scQuestionID desc
	Insert into [dbo].[scQuestions](scQuestionID,ParamID,ParamTitle,Seq,scSectionID,QWght,isMandatory,IsCommentReq,ScorecardID) --Output Inserted.scQuestionID into @Questionid
		Values(@topQuestionId,@paramId, @paramName,Isnull(@Qseq,0)+1,@SectionId,@ParamWeight,@isMandatory,@isCurrentReq,@ScoreCardId)


END 
 
 
 
END

GO
/****** Object:  StoredProcedure [dbo].[InsertIntoSections]    Script Date: 4/22/2021 10:47:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE Procedure [dbo].[InsertIntoSections]  
(  
@sectionName varchar(51),  
@SectionWght int,  
@ScorecardName varchar(21),
@CompanyID int
)  
AS  
BEGIN   
declare @Sectionid int;  
declare @ScorecardID int;  
declare @Seccnt int;
declare @SCSecsWght as int;
declare @beforesecscore int;
select @Sectionid=1
select @ScoreCardid=ScorecardID from ScorecardMaster(nolock)  where ScorecardName=@ScorecardName and CompanyID=@CompanyID 
select top 1 @Sectionid=scSectionID from scSections(nolock) Order by scSectionID desc   
select @beforesecscore=0;
IF (@sectionName != 'General')
	Begin
	select  @Seccnt=count(*) from scSections(nolock) where ScorecardID=@ScoreCardid
	select @beforesecscore=sum(Qwght) from scQuestions where scSectionID=(select  top 1 scSectionID from scSections where ScorecardID=@ScorecardID order by scSectionID desc)
	select @SCSecsWght=sum(SectionWght) from scSections where ScorecardID=@ScorecardID
	End
	
IF ( @SCSecsWght + @SectionWght <= 100 OR @sectionName = 'General')
Begin
	IF (@beforesecscore = 100 OR @sectionName = 'General' Or @Seccnt = 1) 
		BEGIN
		Insert into scSections(scSectionID,SectionName,SectionWght,IsNewPage,ScorecardID,Seq)  
		select @Sectionid+1 ,@sectionName,@SectionWght,0,@ScorecardID,(select top 1 seq from scSections(nolock) where ScorecardID=@ScorecardID order by seq desc )+1  
		END
	ELSE
		BEGIN
		Insert into scSections(scSectionID,SectionName,SectionWght,IsNewPage,ScorecardID,Seq)  
		select @Sectionid ,@sectionName,@SectionWght,0,@ScorecardID,(select top 1 seq from scSections(nolock) where ScorecardID=@ScorecardID order by seq desc )+1  
		END
End
Else
	BEGIN
	Insert into scSections(scSectionID,SectionName,SectionWght,IsNewPage,ScorecardID,Seq)  
	select @Sectionid ,@sectionName,@SectionWght,0,@ScorecardID,(select top 1 seq from scSections(nolock) where ScorecardID=@ScorecardID order by seq desc )+1  
	END

--select SCOPE_IDENTITY()  
  
END


GO
/****** Object:  StoredProcedure [dbo].[SaveDraftAuditDetails]    Script Date: 4/22/2021 10:47:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE Procedure [dbo].[SaveDraftAuditDetails]      
(@CompanyId int,
@ScorecardID int,
@Responce nvarchar(max),
@Comments nvarchar(max),
@QScore nvarchar(max)=null,
@Type nvarchar(50),
@UserId int,
@SectionIds nvarchar(max)
)      
AS      
BEGIN 
DECLARE @id int;
DECLARE @arid int;
DECLARE @auditID int;
DECLARE @auditscore decimal(5,2);
SET @id = 0;
SET @arid = 0
SELECT top(1) @id=AuditID FROM Audits ORDER BY AuditID DESC;
SELECT @id
INSERT INTO Audits ([AuditID],[ScorecardID],[ADate],[Status],[UserID]) Values(@id+1,@ScorecardID,getdate(),@Type,@UserId);
set @auditID=@id+1;

 

CREATE TABLE #temp (Target_Coulmn  nvarchar(max))
                ----Split with comma and Insert into #temp table
INSERT INTO  #temp SELECT CAST(Items AS  nvarchar(max)) FROM  dbo.Split(@Responce, ',') ;
--INSERT INTO  #temp SELECT value FROM  dbo.Split(@Responce, ',') ;
update #temp set Target_Coulmn = replace(replace(DBO.FN_REPLACE_FIRST(Target_Coulmn,'-','#'),'-',' '),'#','-')
where (LEN(Target_Coulmn) - LEN(REPLACE(Target_Coulmn, '-', ''))) > 2
--select * from #temp
 

 

INSERT INTO AuditReponses ([AuditID],[scQuestionID],[Response],[Score]) 
Select @auditID,REVERSE(PARSENAME(REPLACE(REVERSE(Target_Coulmn), '-', '.'), 1)),
REVERSE(PARSENAME(REPLACE(REVERSE(Target_Coulmn), '-', '.'), 2)),
REPLACE(REVERSE(PARSENAME(REPLACE(REVERSE(REPLACE(Target_Coulmn,'.','|')), '-', '.'), 3)),'|','.') FROM #temp;

--Select @auditID,REVERSE(PARSENAME(REPLACE(REVERSE(Target_Coulmn), '-', '.'), 1)),REVERSE(PARSENAME(REPLACE(REVERSE(Target_Coulmn), '-', '.'), 2)),REPLACE(REVERSE(PARSENAME(REPLACE(REVERSE(REPLACE(Target_Coulmn,'.','|')), '-', '.'), 3)),'|','.') FROM #temp;
 

CREATE TABLE #temp1 (Target_Coulmn  nvarchar(max))
                ----Split with comma and Insert into #temp table
INSERT INTO  #temp1 SELECT CAST(Items AS  nvarchar(max)) FROM  dbo.Split(@Comments, ',') ;
--INSERT INTO  #temp1 SELECT value1 FROM  dbo.Split(@Comments, ',') ;

 

CREATE TABLE #temp2 (Target_Coulmn1  nvarchar(max),Target_Coulmn2  nvarchar(max));
INSERT INTO  #temp2 SELECT REVERSE(PARSENAME(REPLACE(REVERSE(Target_Coulmn), '-', '.'), 1)),
REVERSE(PARSENAME(REPLACE(REVERSE(Target_Coulmn), '-', '.'), 2)) FROM  #temp1 ;

 

Merge AuditReponses as target
using #temp2  as source
on
target.AuditID=@auditID and target.scQuestionID=source.Target_Coulmn1
When matched 
Then
update 
set target.Comments=source.Target_Coulmn2
When not matched by Target Then
INSERT ([AuditID],[scQuestionID],[Comments]) Values(@auditID,Target_Coulmn1,Target_Coulmn2);
DROP TABLE #temp;
DROP TABLE #temp1;
DROP TABLE #temp2;

 

CREATE TABLE #temp3 (Target_Coulmn3  nvarchar(max))
                ----Split with comma and Insert into #temp table
INSERT INTO  #temp3 SELECT CAST(Items AS  nvarchar(max)) FROM  dbo.Split(@SectionIds, ',') ;

select * from #temp3
Select @auditID,REVERSE(PARSENAME(REPLACE(REVERSE(Target_Coulmn3), '-', '.'), 1)),
replace(REVERSE(PARSENAME(REPLACE(REVERSE(replace(Target_Coulmn3,'.','|')), '-', '.'), 2)),'|','.') FROM #temp3;;

INSERT INTO [dbo].[AuditResponseCalculations] ([AuditId],[SecSectionId],[SecScore]) 
Select @auditID,REVERSE(PARSENAME(REPLACE(REVERSE(Target_Coulmn3), '-', '.'), 1)),
replace(REVERSE(PARSENAME(REPLACE(REVERSE(replace(Target_Coulmn3,'.','|')), '-', '.'), 2)),'|','.') FROM #temp3;;

DROP TABLE #temp3;

select @auditscore = sum(CAST(SecScore AS decimal(5,2))) from [AuditResponseCalculations] where [AuditId]=@auditID

update AuditReponses set Score = @auditscore where AuditID=@auditID and
scQuestionID = (select scQuestionID from scQuestions where ParamID=34 and ScorecardID=@ScorecardID)

END  

 


GO
/****** Object:  StoredProcedure [dbo].[sp_GetAppUser]    Script Date: 4/22/2021 10:47:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[sp_GetAppUser] 
(
@CompanyId int)
AS          
  BEGIN          
            
   Select * from [dbo].[UserInfo] where CompanyID=@CompanyId
      
  END 

GO
/****** Object:  StoredProcedure [dbo].[sp_GetCountries]    Script Date: 4/22/2021 10:47:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[sp_GetCountries]          
AS          
  BEGIN          
            
   SELECT Country FROM [dbo].[Countries]
      
  END 

GO
/****** Object:  StoredProcedure [dbo].[sp_GetDaynamicdata]    Script Date: 4/22/2021 10:47:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
Create PROCEDURE [dbo].[sp_GetDaynamicdata]  
(
@ScorecardName varchar(20)
)
AS          
  BEGIN
  SELECT * FROM [dbo].[ScorecardMaster] (nolock) scm 
   inner join scSections (nolock) ss on scm.ScorecardID=ss.ScorecardID
   inner join scQuestions (nolock) sq on sq.scSectionID=ss.scSectionID
   inner join scQLov (nolock)  sql1 on sql1.scQuestionID=sq.scQuestionID
   inner join ParaMaster (nolock) pm on pm.ParamID=sq.ParamID
   where scm.ScorecardName=@ScorecardName 
  END 

GO
/****** Object:  StoredProcedure [dbo].[sp_GetDriveforSolution]    Script Date: 4/22/2021 10:47:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
Create PROCEDURE [dbo].[sp_GetDriveforSolution]          
AS          
  BEGIN          
           
   SELECT ParamTitle,ParamID,scSectionID FROM [dbo].[scQuestions] where scSectionID=4   
      
  END 

  --exec sp_GetDriveforSolution

GO
/****** Object:  StoredProcedure [dbo].[sp_GetResolution]    Script Date: 4/22/2021 10:47:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
Create PROCEDURE [dbo].[sp_GetResolution]          
AS          
  BEGIN          
           
   SELECT ParamTitle,ParamID,scSectionID FROM [dbo].[scQuestions] where scSectionID=3     
      
  END 

   --exec sp_GetResolution

GO
/****** Object:  StoredProcedure [dbo].[sp_GetSoftSkills]    Script Date: 4/22/2021 10:47:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
 Create PROCEDURE [dbo].[sp_GetSoftSkills]          
AS          
  BEGIN          
           
   SELECT ParamTitle,ParamID,scSectionID FROM [dbo].[scQuestions] where scSectionID=5    
      
  END 

   --exec sp_GetSoftSkills

GO
/****** Object:  StoredProcedure [dbo].[sp_GetUser]    Script Date: 4/22/2021 10:47:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
Create PROCEDURE [dbo].[sp_GetUser] 
(
@UserName Varchar(10), @PCode Varchar(10))
AS          
  BEGIN          
            
   SELECT *  FROM [dbo].[UserInfo] where UserName =  @UserName and PCode=@PCode  
      
  END 



GO
/****** Object:  StoredProcedure [dbo].[sp_UpdateScorecard]    Script Date: 4/22/2021 10:47:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[sp_UpdateScorecard]   
(
@ScoreCardNM nvarchar(25),
@CompanyId int)

AS          
  BEGIN          
  declare @scwghtcnt int;
  declare @ScoreCardID int;
  declare @totscwt int;
  declare @gensecid int;

  CREATE TABLE #ScWgt ( SecID INT, Wtg INT );

   select @ScoreCardID=ScorecardID from  ScorecardMaster where ScorecardName=@ScoreCardNM and CompanyID=@CompanyId
   select @gensecid= scSectionID from scSections where ScorecardID=@ScoreCardID and SectionName='General' 
  
  select @totscwt=isnull(sum(SectionWght),0) from scSections where ScorecardID=@ScoreCardID
   
   insert into #ScWgt
   select scSectionID, sum(QWght) from scQuestions where ScorecardID=@ScoreCardID and  scSectionID <> @gensecid
   group by scSectionID
  
   
   select @scwghtcnt=isnull(count(SecID),0) from #ScWgt where Wtg < 100

   if @scwghtcnt = 0 and @totscwt = 100
   update ScorecardMaster set Status=1 where ScorecardID=@ScoreCardID
   else
   update ScorecardMaster set Status=200 where ScorecardID='8577yu'
  
  drop table #ScWgt
  
  END 

GO
/****** Object:  StoredProcedure [dbo].[sp_UpdateScorecardStatus]    Script Date: 4/22/2021 10:47:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[sp_UpdateScorecardStatus]   
(
@ScoreCardNM nvarchar(25),
@CompanyId int,
@status int)
AS          
  BEGIN   
  declare @Scid int;
  declare @AuditCnt int;
  select @AuditCnt=0;
 
  select @Scid=ScorecardID from  ScorecardMaster where ScorecardName=@ScoreCardNM and CompanyID=@CompanyId
   select @AuditCnt=count(*) from Audits where ScorecardID=@Scid and Status=0
   if @AuditCnt = 0 
	update ScorecardMaster set Status=@status where ScorecardID=@Scid
   else 
    update ScorecardMaster set Status='100' where ScorecardID=@Scid
  END

GO
/****** Object:  StoredProcedure [dbo].[UpdateDepartment]    Script Date: 4/22/2021 10:47:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE procedure [dbo].[UpdateDepartment]  
(  
   @CompanyId int,  
   @CompanyName varchar (50),
   @Address varchar (250),
   @url varchar (50),
   @ContactNo varchar (10)
)  
as  
begin  
   Update CompanyMaster  
   set CompanyName=@CompanyName, 
   Address=@Address ,url= @url , ContactNo = @ContactNo
   where CompanyId=@CompanyId  
End  

GO
/****** Object:  StoredProcedure [dbo].[UpdateTeams]    Script Date: 4/22/2021 10:47:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE procedure [dbo].[UpdateTeams]  
(  
  @Teamid int,
  @TeamName varchar(20),
  @TeamLeadId int
)  
as  
begin  

UPDATE [dbo].[Teams]
   SET [TeamName] = @TeamName
      ,[TeamLeadID] = @TeamLeadId
 WHERE TeamId= @TeamId

End  

GO
/****** Object:  StoredProcedure [dbo].[UpdateUser]    Script Date: 4/22/2021 10:47:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE procedure [dbo].[UpdateUser]  
(  
   @UserId int,
   @UserName varchar (10),
   @DisplayName varchar (25),
   @CompanyId int,
   @RoleId int,
   @Email varchar (56),
   @MgrId int,
   @Dob date,
   @Country nvarchar(20),
   @Gender nvarchar(10),
   @StartDate date,
   @EndDate date

)  
as  
begin  
   
   Update [dbo].[UserMaster] set
           [CompanyID] = @CompanyId, [RoleID]=  @RoleId
           ,[UserName] = @UserName,[DisplayName] = @DisplayName
           ,[MgrID] = @MgrId ,[Email] = @Email,
		   [DOB] = @Dob, [Country] = @Country,
		   [Gender] = @Gender,
		   [StartDate] = @StartDate,
		   [EndDate] = @EndDate
     wHERE UserID = @UserId   


End  

GO
/****** Object:  StoredProcedure [dbo].[Usp_DeleteintoParams]    Script Date: 4/22/2021 10:47:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE Procedure [dbo].[Usp_DeleteintoParams]
(
@QuestionId Int
)
AS
BEGIN

declare @Scname nvarchar(60)

select @Scname = s.SectionName from scQuestions q, scSections s
where q.scSectionID=s.scSectionID and q.scQuestionID=@QuestionId

IF @Scname != 'General' 
Begin
print '1'
delete from scQLov where scQuestionID =@QuestionId
delete from  scQuestions where scQuestionID =@QuestionId
End
IF @Scname = 'General' 
Begin
print '2'
delete from scQLov where scQuestionID= 'NOQID'
End

END 

GO
/****** Object:  StoredProcedure [dbo].[Usp_DeleteIntoSectionData]    Script Date: 4/22/2021 10:47:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
Create  Procedure [dbo].[Usp_DeleteIntoSectionData]
(@sectionId int)
AS
BEGIN
  delete from  scQLov where scQuestionID in (select scQuestionID from  scQuestions where scSectionID=@SectionId)
  delete from  scQuestions where scSectionID=@SectionId
  delete  from  scSections where scSectionID=@SectionId

END

GO
/****** Object:  StoredProcedure [dbo].[usp_GetAgentUsers]    Script Date: 4/22/2021 10:47:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE Procedure [dbo].[usp_GetAgentUsers]  
(@compid int=null)
as    
begin    
   select U.[UserId],U.DisplayName,
         R.RoleName,U.CompanyID
       from UserMaster U
	  Inner join CompanyMaster D on D.CompanyId=U.CompanyId
	  Inner join RoleMaster R on R.RoleId=U.RoleId 
	  where U.RoleID != 2  and U.Status != 9
End   

GO
/****** Object:  StoredProcedure [dbo].[USP_GetParamDataGrid]    Script Date: 4/22/2021 10:47:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE procedure [dbo].[USP_GetParamDataGrid]
(@ScorecardName Varchar(50),@sectionname Varchar(50))
AS
BEGIN

declare @ScorecardID int;
select @ScorecardID=ScorecardID from ScorecardMaster(nolock)  where ScorecardName=@ScorecardName  

select ParamName,ParamTitle,QWght,isMandatory,IsCommentReq,scQuestionID,SS.ScorecardID,ss.scSectionID,SQS.ParamID
from [dbo].[scSections](nolock) SS
  Inner join [dbo].[scQuestions](nolock) SQS on SS.ScorecardID=SQS.ScorecardID and ss.scSectionID=SQS.scSectionID
  Inner join  [dbo].[ParaMaster] (nolock) PM on SQS.ParamID=PM.ParamID
  where SS.SectionName=@sectionname and ss.ScorecardID=@ScorecardID

END

--exec USP_GetParamDataGrid 'New Sample Card','Section 1'




GO
/****** Object:  StoredProcedure [dbo].[Usp_GetSectionQDetails]    Script Date: 4/22/2021 10:47:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE Procedure [dbo].[Usp_GetSectionQDetails]      
(@ScoreCardName Varchar(26),
@CompanyID int
)      
AS      
BEGIN      
      
select SM.ScorecardID ,SM.ScorecardName,SS.scSectionID,SS.SectionName,SS.SectionWght,SS.Seq as SectionSeq,SQ.ParamID,SQ.ParamTitle,SQ.Seq AS QSeq,SQ.QWght,    
SQ.isMandatory,SQ.IsCommentReq,SCL.scQLOVID,SCL.scQuestionValues,SCL.scWeightage,PM.IsDefault,SQ.scQuestionID,PM.ParamType    
 from [dbo].[ScorecardMaster](nolock) SM      
Inner Join scSections(nolock) SS on SM.ScorecardID=SS.ScorecardID      
Inner join scQuestions(nolock) SQ on SS.scSectionID= SQ.scSectionID and SS.ScorecardID=SQ.ScorecardID      
LEFT join scQLov(nolock) SCL on SQ.scQuestionID =SCL.scQuestionID and SCL.scQLOVID is not null      
Inner join [dbo].[ParaMaster](nolock) PM on SQ.ParamID= PM.ParamID      
where SM.ScorecardName=@ScoreCardName and SM.CompanyID = @CompanyID     

 


--select SM.ScorecardID,SM.ScorecardName,(select SS.scSectionID,SS.SectionName,SS.SectionWght,SS.Seq as SectionSeq
--,(select SQ.ParamID,SQ.ParamTitle,SQ.Seq AS QSeq,SQ.QWght,    
--SQ.isMandatory,SQ.IsCommentReq,SQ.scQuestionID,PM.ParamType,PM.IsDefault 
--,(select SCL.scQLOVID,SCL.scQuestionValues
--From  scQLov(nolock) SCL Where SQ.scQuestionID =SCL.scQuestionID and SCL.scQLOVID is not null   for json path) as Qvalues
--From  scQuestions(nolock) SQ
--Inner join [dbo].[ParaMaster](nolock) PM on SQ.ParamID= PM.ParamID WHERE SS.scSectionID= SQ.scSectionID and SS.ScorecardID=SM.ScorecardID   for json path) as Questions 
--From  scSections(nolock) SS where SM.ScorecardID=SS.ScorecardID for json path ) as SectionName
--from [dbo].[ScorecardMaster](nolock) SM where SM.ScorecardName=@ScoreCardName   

 

END  

 

-- exec Usp_GetSectionQDetails 'Sample Scorecard'

GO
/****** Object:  StoredProcedure [dbo].[usp_InsertIntoCompany]    Script Date: 4/22/2021 10:47:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE procedure [dbo].[usp_InsertIntoCompany]
(@CompanyName Varchar(40),@Address Varchar(100), @ContactNo Varchar(10),@url Varchar(70))
AS
BEGIN

declare @Companyid int;


Select @Companyid=1 

print @Companyid

select top 1 @Companyid=CompanyID from CompanyMaster(nolock) Order by CompanyID desc 
Insert into CompanyMaster(CompanyID,CompanyName, Status, Address,ContactNo, url)
select @Companyid+1 ,@CompanyName,0,@Address,@ContactNo,@url

END 

GO
/****** Object:  StoredProcedure [dbo].[usp_InsertIntoScoreCardMaster]    Script Date: 4/22/2021 10:47:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE procedure [dbo].[usp_InsertIntoScoreCardMaster]
(@ScoreCardname Varchar(25),@CompanyID int)
AS
BEGIN

declare @ScoreCardid int;
declare @scardid int;
declare @Sectionid int;

Select @ScoreCardid=1 

print @ScoreCardid

select top 1 @ScoreCardid=ScorecardID from ScorecardMaster(nolock) Order by ScorecardID desc 
Insert into ScorecardMaster(ScorecardID,ScorecardName, Status, CompanyID)
select @ScoreCardid+1 ,@ScoreCardname,0,@CompanyID

EXEC dbo.InsertIntoSections  'General',0,@ScoreCardname,@CompanyID

print @ScoreCardid

select  @Sectionid=scSectionID,@scardid=ScorecardID from dbo.scSections(nolock) where SectionName='General' and ScorecardID=@ScoreCardid+1

Exec dbo.InsertIntoParams @scardid ,@Sectionid,1,'Agent',0,False,True
Exec dbo.InsertIntoParams @scardid,@Sectionid,2,'Auditor',0,False,True
Exec dbo.InsertIntoParams @scardid,@Sectionid,3,'Ticket ID',0,False,True
Exec dbo.InsertIntoParams @scardid,@Sectionid,4,'Audit Date',0,False,True
Exec dbo.InsertIntoParams @scardid,@Sectionid,5,'Ticket Date',0,False,True
Exec dbo.InsertIntoParams @scardid,@Sectionid,33,'Rating',0,False,True
Exec dbo.InsertIntoParams @scardid,@Sectionid,32,'Customer Name',0,False,True
Exec dbo.InsertIntoParams @scardid,@Sectionid,34,'Audit Score',0,False,True


END 

GO
/****** Object:  StoredProcedure [dbo].[usp_rpt_meanaverageReportbyScoreCardId]    Script Date: 4/22/2021 10:47:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- Exec dbo.usp_meanaverageReportbyScoreCardId 2
CREATE procedure [dbo].[usp_rpt_meanaverageReportbyScoreCardId]
(
	 @ScorecardId Int
)

AS
BEGIN
--Drop table #AuditReportData

	IF OBJECT_ID('tempdb..#AuditReportData') IS NOT NULL
	Begin
	  DROP TABLE #AuditReportData
	END

	IF OBJECT_ID('tempdb..#AuditScore') IS NOT NULL
	Begin
	  DROP TABLE #AuditScore
	END

	IF OBJECT_ID('tempdb..#AuditReport') IS NOT NULL
	Begin
	  DROP TABLE #AuditReport
	END


	Create Table #AuditReportData (AuditID numeric, ADate Date, AuditStatus Nvarchar(255),UserName Nvarchar(255) , 
					ParamTitle Nvarchar(255), Response Nvarchar(255), TeamName Nvarchar(255),TeamLead Nvarchar(255))


	Insert into #AuditReportData
	Select Ad.AuditID, Ad.ADate, 
		Case Ad.Status 
			When 0 Then 'Rejected'
			When 1 Then 'Accepted'	
			When 2 Then 'Challenged'
			When 3 Then 'Cancelled'
			End
	, UM.DisplayName, SQ.ParamTitle, Ar.Response, tm.TeamName,  tmgr.UserName 
	from Audits Ad
	Inner Join AuditReponses Ar on Ad.AuditID = ar.AuditID
	Inner join scQuestions SQ on Ar.scQuestionID = SQ.scQuestionID
	Inner join UserMaster UM on Ad.UserID = UM.UserID
	Left Join Teams Tm on UM.MgrID  = TM.TeamLeadID
	Inner Join UserMaster Tmgr On Tm.TeamLeadID = tmgr.UserID
	Where Ad.ScorecardID = @ScorecardId 

	--Insert into #AuditScore
	Select Ad.AuditID, Round(AVG(COnvert(numeric, Ar.Score)),2) as [Audit Score] Into #AuditScore
	from Audits Ad
	Inner Join AuditReponses Ar on Ad.AuditID = ar.AuditID
	Where Ad.ScorecardID = @ScorecardId 
	Group By Ad.AuditID

	Select Ad.AuditID, Round(AVG(COnvert(numeric, ISNULL(Ar.Score,0))),2) as [Parameter Average Score] Into #ParameterScore
	
	from Audits Ad
	Inner Join AuditReponses Ar on Ad.AuditID = ar.AuditID
	Where Ad.ScorecardID = @ScorecardId 
	Group By Ad.AuditID



	SELECT 
		[AuditID], [Agent] as [Agent Name], [Auditor] as [Audited By],[Audit Date],[Rating] as [Customer Rating],
		AuditStatus as [Status], TeamName as Team,TeamLead as [Team Lead] 
	Into #AuditReport
	from (SELECT AuditID,AuditStatus, UserName,TeamName, TeamLead,ParamTitle, Response 
	FROM [dbo].#AuditReportData
	)x pivot (max(Response) for ParamTitle in ([Agent],[Audit Date],[Auditor],[Rating])) p

	Select 
			AR.[AuditID] As AuditId,  [Agent Name] as AgentName, [Audited By] as AuditedBy,[Audit Date] as AuditDate, [Customer Rating] as CustomerRating,
			Cast(CONVERT(DECIMAL(10,2),[Audit Score]) as nvarchar) as AuditScore,
			Cast(CONVERT(DECIMAL(10,2),[Parameter Average Score]) as nvarchar) as ParameterAverageScore,
			[Status],  Team, [Team Lead] as TeamLead
	From #AuditReport AR 
	Inner Join #AuditScore Sr on AR.[AuditID] = sr.AuditID
	inner Join #ParameterScore PSr on AR.[AuditID] = Psr.AuditID
END

GO
/****** Object:  StoredProcedure [dbo].[usp_rpt_MetNotMet]    Script Date: 4/22/2021 10:47:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



-- Exec dbo.usp_meanaverageReportbyScoreCardId 2
CREATE procedure [dbo].[usp_rpt_MetNotMet]
(
	 @ScorecardId Int
)

AS
BEGIN
--Drop table #AuditReportData

	IF OBJECT_ID('tempdb..#AuditReportMetNotMetData') IS NOT NULL
	Begin
	  DROP TABLE #AuditReportMetNotMetData
	END
	IF OBJECT_ID('tempdb..#AuditRepNMet') IS NOT NULL
	Begin
	  DROP TABLE #AuditRepNMet
	END

	Create Table #AuditReportMetNotMetData (Title nvarchar(80), Met int, NotMet int)

	Create Table #AuditRepNMet (Title nvarchar(80), Cnt int)

	Insert into #AuditRepNMet
	select UserName, count(AuditId) as NotMet  from [dbo].[rptCoversionRateVw]
	where score < 75 and scorecardid=2 group by UserName 

	
	Insert into #AuditReportMetNotMetData
	select UserName, count(AuditId) as Met, 0 as NotMet  from [dbo].[rptCoversionRateVw]
	where score > 75 and scorecardid=@ScorecardId group by UserName 

	--print '1'
	--select * from #AuditReportParamPassData

	update #AuditReportMetNotMetData set #AuditReportMetNotMetData.NotMet=#AuditRepNMet.Cnt
	from #AuditRepNMet inner join #AuditReportMetNotMetData on
	#AuditRepNMet.Title = #AuditReportMetNotMetData.Title 


	Select * from #AuditReportMetNotMetData

	--print '4'
	--select * from #AuditReportParamData
   
	

END

GO
/****** Object:  StoredProcedure [dbo].[usp_rpt_ParamaverageReportbyScoreCardId]    Script Date: 4/22/2021 10:47:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- Exec dbo.usp_meanaverageReportbyScoreCardId 2
CREATE procedure [dbo].[usp_rpt_ParamaverageReportbyScoreCardId]
(
	 @ScorecardId Int
)

AS
BEGIN
--Drop table #AuditReportData

	IF OBJECT_ID('tempdb..#AuditReportParamPassData') IS NOT NULL
	Begin
	  DROP TABLE #AuditReportParamPassData
	END
	IF OBJECT_ID('tempdb..#AuditReportParamFailData') IS NOT NULL
	Begin
	  DROP TABLE #AuditReportParamFailData
	END

	IF OBJECT_ID('tempdb..#AuditReportParamData') IS NOT NULL
	Begin
	  DROP TABLE #AuditReportParamData
	END


	Create Table #AuditReportParamPassData (UserId int, Title nvarchar(100), Cnt int)

	Create Table #AuditReportParamFailData (UserId int, Title nvarchar(100), Cnt int)

	Insert into #AuditReportParamPassData
	select AD.UserID,SQ.ParamTitle, count(*) as Cnt 
	from Audits AD
	inner join AuditReponses AR on AR.AuditID = AD.AuditID
	inner join scQuestions SQ on AR.scQuestionID= SQ.scQuestionID 
	where SQ.ParamID > 5 and SQ.ParamID != 33 and SQ.ParamID != 32 and AR.Score='100' and SQ.ScorecardID=@ScorecardId
	group by AD.UserID,SQ.ParamTitle

	--print '1'
	--select * from #AuditReportParamPassData

	Insert into #AuditReportParamFailData
	select AD.UserID,SQ.ParamTitle, count(*) as Cnt 
	from Audits AD
	inner join AuditReponses AR on AR.AuditID = AD.AuditID
	inner join scQuestions SQ on AR.scQuestionID= SQ.scQuestionID 
	where SQ.ParamID > 5 and SQ.ParamID != 33 and SQ.ParamID != 32 and AR.Score !='100' and SQ.ScorecardID=@ScorecardId
	group by AD.UserID,SQ.ParamTitle

	--print '2'
	--select * from #AuditReportParamFailData
	
	Create Table #AuditReportParamData (UserId int, Title nvarchar(100), pCnt int,fCnt int)

	Insert into #AuditReportParamData 
	Select UserId,Title,cnt,0 from 
	#AuditReportParamPassData

	--print '3'
	--select * from #AuditReportParamData

	update #AuditReportParamData set #AuditReportParamData.fCnt=#AuditReportParamFailData.Cnt
	from #AuditReportParamData inner join #AuditReportParamFailData on
	#AuditReportParamFailData.Title = #AuditReportParamData.Title and 
	#AuditReportParamFailData.UserId = #AuditReportParamData.UserId

	--print '4'
	--select * from #AuditReportParamData

	insert into #AuditReportParamData 
	Select UserId,Title,0,cnt from #AuditReportParamFailData
	where #AuditReportParamFailData.Title not in (Select Title from #AuditReportParamData)


	Select UM.DisplayName, Title, pCnt, fCnt, pCnt+fCnt,
	case 
	when pCnt > 0 then (pCnt /(pCnt+fCnt)) * 100
	when pCnt = 0 then 0 end as PCntg, 
	case 
	when fCnt > 0 then 	(fCnt/(pCnt+fCnt)) * 100
	when fCnt = 0 then 0 end as fPCntg,   (Select TeamName from Teams (nolock) where TeamLeadID= UM.MgrID) as MgrID from #AuditReportParamData RPTD Inner Join
	UserMaster UM ON RPTD.UserId=UM.UserID order by UM.DisplayName, Title
	

END

GO
/****** Object:  StoredProcedure [dbo].[usp_rpt_SummaryMASReportbyScoreCardId]    Script Date: 4/22/2021 10:47:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE procedure [dbo].[usp_rpt_SummaryMASReportbyScoreCardId]
(
	 @ScorecardId Int
)
AS
BEGIN

declare @temp table
(
    AuditId int,
    AgentName varchar(25),
    AuditedBy varchar(25),
    AuditDate varchar(15),
    CustomerRating numeric(5,2),
    AuditScore numeric(5,2),
    ParameterAverageScore numeric(5,2),
    Status varchar(15),
	Team varchar(25),
	TeamLead varchar(25)
);
INSERT @temp  EXEC [dbo].[usp_rpt_meanaverageReportbyScoreCardId] @ScorecardID = @ScorecardId; 
select count(AuditId) as AuditCnt,CONVERT(DECIMAL(10,2),Sum(AuditScore)/Count(AuditId)) as AuditAvg, 
CONVERT(DECIMAL(10,2), sum(ParameterAverageScore)/Count(AuditId)) 
as AuditPAvg  from @temp;

END

GO
/****** Object:  StoredProcedure [dbo].[Usp_UpdateintoParams]    Script Date: 4/22/2021 10:47:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
 
create Procedure [dbo].[Usp_UpdateintoParams]
(
@QuestionId Int,
@Title  Varchar(200)
)
AS
BEGIN
Update scQuestions set ParamTitle=@Title where scQuestionID =@QuestionId
END
 

GO
/****** Object:  StoredProcedure [dbo].[Usp_UpdateIntoSectionData]    Script Date: 4/22/2021 10:47:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
create procedure [dbo].[Usp_UpdateIntoSectionData]
(@SectionId int ,
@sectionName Varchar(50),
@sectionWeigh int
)
AS
Begin 
  Update scSections set SectionName=@sectionName,SectionWght=@sectionWeigh where scSectionID=@SectionId
END 

GO
EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPane1', @value=N'[0E232FF0-B466-11cf-A24F-00AA00A3EFFF, 1.00]
Begin DesignProperties = 
   Begin PaneConfigurations = 
      Begin PaneConfiguration = 0
         NumPanes = 4
         Configuration = "(H (1[40] 4[20] 2[20] 3) )"
      End
      Begin PaneConfiguration = 1
         NumPanes = 3
         Configuration = "(H (1 [50] 4 [25] 3))"
      End
      Begin PaneConfiguration = 2
         NumPanes = 3
         Configuration = "(H (1 [50] 2 [25] 3))"
      End
      Begin PaneConfiguration = 3
         NumPanes = 3
         Configuration = "(H (4 [30] 2 [40] 3))"
      End
      Begin PaneConfiguration = 4
         NumPanes = 2
         Configuration = "(H (1 [56] 3))"
      End
      Begin PaneConfiguration = 5
         NumPanes = 2
         Configuration = "(H (2 [66] 3))"
      End
      Begin PaneConfiguration = 6
         NumPanes = 2
         Configuration = "(H (4 [50] 3))"
      End
      Begin PaneConfiguration = 7
         NumPanes = 1
         Configuration = "(V (3))"
      End
      Begin PaneConfiguration = 8
         NumPanes = 3
         Configuration = "(H (1[56] 4[18] 2) )"
      End
      Begin PaneConfiguration = 9
         NumPanes = 2
         Configuration = "(H (1 [75] 4))"
      End
      Begin PaneConfiguration = 10
         NumPanes = 2
         Configuration = "(H (1[66] 2) )"
      End
      Begin PaneConfiguration = 11
         NumPanes = 2
         Configuration = "(H (4 [60] 2))"
      End
      Begin PaneConfiguration = 12
         NumPanes = 1
         Configuration = "(H (1) )"
      End
      Begin PaneConfiguration = 13
         NumPanes = 1
         Configuration = "(V (4))"
      End
      Begin PaneConfiguration = 14
         NumPanes = 1
         Configuration = "(V (2))"
      End
      ActivePaneConfig = 0
   End
   Begin DiagramPane = 
      Begin Origin = 
         Top = 0
         Left = 0
      End
      Begin Tables = 
         Begin Table = "arc"
            Begin Extent = 
               Top = 9
               Left = 57
               Bottom = 206
               Right = 399
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "adt"
            Begin Extent = 
               Top = 9
               Left = 456
               Bottom = 206
               Right = 694
            End
            DisplayFlags = 280
            TopColumn = 0
         End
      End
   End
   Begin SQLPane = 
   End
   Begin DataPane = 
      Begin ParameterDefaults = ""
      End
      Begin ColumnWidths = 9
         Width = 284
         Width = 1000
         Width = 1000
         Width = 1000
         Width = 1000
         Width = 1000
         Width = 1000
         Width = 1000
         Width = 1000
      End
   End
   Begin CriteriaPane = 
      Begin ColumnWidths = 12
         Column = 1440
         Alias = 900
         Table = 1170
         Output = 720
         Append = 1400
         NewValue = 1170
         SortType = 1350
         SortOrder = 1410
         GroupBy = 1350
         Filter = 1350
         Or = 1350
         Or = 1350
         Or = 1350
      End
   End
End
' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'VIEW',@level1name=N'rptCoversionRateVw'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPaneCount', @value=1 , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'VIEW',@level1name=N'rptCoversionRateVw'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPane1', @value=N'[0E232FF0-B466-11cf-A24F-00AA00A3EFFF, 1.00]
Begin DesignProperties = 
   Begin PaneConfigurations = 
      Begin PaneConfiguration = 0
         NumPanes = 4
         Configuration = "(H (1[40] 4[20] 2[20] 3) )"
      End
      Begin PaneConfiguration = 1
         NumPanes = 3
         Configuration = "(H (1 [50] 4 [25] 3))"
      End
      Begin PaneConfiguration = 2
         NumPanes = 3
         Configuration = "(H (1 [50] 2 [25] 3))"
      End
      Begin PaneConfiguration = 3
         NumPanes = 3
         Configuration = "(H (4 [30] 2 [40] 3))"
      End
      Begin PaneConfiguration = 4
         NumPanes = 2
         Configuration = "(H (1 [56] 3))"
      End
      Begin PaneConfiguration = 5
         NumPanes = 2
         Configuration = "(H (2 [66] 3))"
      End
      Begin PaneConfiguration = 6
         NumPanes = 2
         Configuration = "(H (4 [50] 3))"
      End
      Begin PaneConfiguration = 7
         NumPanes = 1
         Configuration = "(V (3))"
      End
      Begin PaneConfiguration = 8
         NumPanes = 3
         Configuration = "(H (1[56] 4[18] 2) )"
      End
      Begin PaneConfiguration = 9
         NumPanes = 2
         Configuration = "(H (1 [75] 4))"
      End
      Begin PaneConfiguration = 10
         NumPanes = 2
         Configuration = "(H (1[66] 2) )"
      End
      Begin PaneConfiguration = 11
         NumPanes = 2
         Configuration = "(H (4 [60] 2))"
      End
      Begin PaneConfiguration = 12
         NumPanes = 1
         Configuration = "(H (1) )"
      End
      Begin PaneConfiguration = 13
         NumPanes = 1
         Configuration = "(V (4))"
      End
      Begin PaneConfiguration = 14
         NumPanes = 1
         Configuration = "(V (2))"
      End
      ActivePaneConfig = 0
   End
   Begin DiagramPane = 
      Begin Origin = 
         Top = 0
         Left = 0
      End
      Begin Tables = 
         Begin Table = "Audits"
            Begin Extent = 
               Top = 6
               Left = 38
               Bottom = 221
               Right = 208
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "AuditReponses"
            Begin Extent = 
               Top = 6
               Left = 246
               Bottom = 136
               Right = 420
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "ScorecardMaster"
            Begin Extent = 
               Top = 0
               Left = 537
               Bottom = 130
               Right = 710
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "ParaMaster"
            Begin Extent = 
               Top = 0
               Left = 842
               Bottom = 130
               Right = 1012
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "scQuestions"
            Begin Extent = 
               Top = 138
               Left = 478
               Bottom = 268
               Right = 649
            End
            DisplayFlags = 280
            TopColumn = 0
         End
      End
   End
   Begin SQLPane = 
   End
   Begin DataPane = 
      Begin ParameterDefaults = ""
      End
      Begin ColumnWidths = 9
         Width = 284
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
      End
   End
   Begin CriteriaPane = 
      Begin ColumnWidths = 11
         Column = 1440
         Ali' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'VIEW',@level1name=N'UserAuditsVw'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPane2', @value=N'as = 900
         Table = 1170
         Output = 720
         Append = 1400
         NewValue = 1170
         SortType = 1350
         SortOrder = 1410
         GroupBy = 1350
         Filter = 1350
         Or = 1350
         Or = 1350
         Or = 1350
      End
   End
End
' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'VIEW',@level1name=N'UserAuditsVw'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPaneCount', @value=2 , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'VIEW',@level1name=N'UserAuditsVw'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPane1', @value=N'[0E232FF0-B466-11cf-A24F-00AA00A3EFFF, 1.00]
Begin DesignProperties = 
   Begin PaneConfigurations = 
      Begin PaneConfiguration = 0
         NumPanes = 4
         Configuration = "(H (1[42] 4[20] 2[12] 3) )"
      End
      Begin PaneConfiguration = 1
         NumPanes = 3
         Configuration = "(H (1 [50] 4 [25] 3))"
      End
      Begin PaneConfiguration = 2
         NumPanes = 3
         Configuration = "(H (1 [50] 2 [25] 3))"
      End
      Begin PaneConfiguration = 3
         NumPanes = 3
         Configuration = "(H (4 [30] 2 [40] 3))"
      End
      Begin PaneConfiguration = 4
         NumPanes = 2
         Configuration = "(H (1 [56] 3))"
      End
      Begin PaneConfiguration = 5
         NumPanes = 2
         Configuration = "(H (2 [66] 3))"
      End
      Begin PaneConfiguration = 6
         NumPanes = 2
         Configuration = "(H (4 [50] 3))"
      End
      Begin PaneConfiguration = 7
         NumPanes = 1
         Configuration = "(V (3))"
      End
      Begin PaneConfiguration = 8
         NumPanes = 3
         Configuration = "(H (1[56] 4[18] 2) )"
      End
      Begin PaneConfiguration = 9
         NumPanes = 2
         Configuration = "(H (1 [75] 4))"
      End
      Begin PaneConfiguration = 10
         NumPanes = 2
         Configuration = "(H (1[66] 2) )"
      End
      Begin PaneConfiguration = 11
         NumPanes = 2
         Configuration = "(H (4 [60] 2))"
      End
      Begin PaneConfiguration = 12
         NumPanes = 1
         Configuration = "(H (1) )"
      End
      Begin PaneConfiguration = 13
         NumPanes = 1
         Configuration = "(V (4))"
      End
      Begin PaneConfiguration = 14
         NumPanes = 1
         Configuration = "(V (2))"
      End
      ActivePaneConfig = 0
   End
   Begin DiagramPane = 
      Begin Origin = 
         Top = 0
         Left = 0
      End
      Begin Tables = 
         Begin Table = "CompanyMaster"
            Begin Extent = 
               Top = 139
               Left = 733
               Bottom = 269
               Right = 906
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "UserMaster"
            Begin Extent = 
               Top = 0
               Left = 188
               Bottom = 214
               Right = 374
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "RoleMaster"
            Begin Extent = 
               Top = 33
               Left = 709
               Bottom = 129
               Right = 879
            End
            DisplayFlags = 280
            TopColumn = 0
         End
      End
   End
   Begin SQLPane = 
   End
   Begin DataPane = 
      Begin ParameterDefaults = ""
      End
      Begin ColumnWidths = 11
         Width = 284
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
      End
   End
   Begin CriteriaPane = 
      Begin ColumnWidths = 11
         Column = 1440
         Alias = 900
         Table = 1170
         Output = 720
         Append = 1400
         NewValue = 1170
         SortType = 1350
         SortOrder = 1410
         GroupBy = 1350
         Filter = 1350
         Or = 1350
         Or = 1350
         Or = 1350
      End
   End
End
' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'VIEW',@level1name=N'UserInfo'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPaneCount', @value=1 , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'VIEW',@level1name=N'UserInfo'
GO
USE [master]
GO
ALTER DATABASE [AuditPilot] SET  READ_WRITE 
GO
